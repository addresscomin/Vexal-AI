# Namaz Guard v3.0 (com.me.blocker)

## Build
GitHub me push karo > Actions > "Build APK" > Artifacts > `NamazGuard-apk`.

## Setup (is order me)
1. App kholo, saari permissions Allow karo (Accessibility, Overlay, Device Admin, Battery, Location, Notifications).
2. Namaz ke waqt check karo / tap karke apne masjid ke waqt save karo.
3. "Apps" me block list aur "lock me bhi khule" list (WhatsApp jaisa) chuno.
4. Guard ON.
5. (Poori suraksha) PC se ek baar Device Owner banao — phone se accounts hatao, phir:
   `adb shell dpm set-device-owner com.me.blocker/.AdminReceiver`
6. Strict mode ON (STRICT likhna padta hai). Iske baad wapas OFF nahi hota.

## Rules
- Namaz ke waqt sab band (sirf call/SMS). 5 min baad "saboot" button khulta hai: camera se LIVE photo leni hoti hai (tick se tasdeeq nahi).
- Deadline tak saboot nahi = qaza: 1 qaza = 60 min poora phone band (sirf call), har agli +30 min, paanchon qaza = 24 ghante.
- Roz ki limit (default 180 min) ke baad din bhar sab band. Us se pehle sirf chune hue apps block.
- Strict + Device Owner: uninstall/disable/force-stop/clear-data/safe-mode/time-change band; lock ke waqt status bar + control center band; split-screen/search/recents se bhi blocked app nahi khulta (lock-task whitelist + accessibility dono).
- Namaz ka waqt strict me calculated se sirf ±30 min badal sakta hai.
- Phone reset hone par hi ye sab khatam hota hai.
