package com.me.blocker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Prefs.armed(c)) return
        BlockerService.start(c)
        when (i.action) {
            "WATCHDOG" -> {
                Policy.sweepMissed(c)
                Scheduler.rescheduleAll(c)
            }
            "PRAYER" -> {
                val idx = i.getIntExtra("idx", 0)
                val day = i.getStringExtra("day") ?: return
                val kind = i.getIntExtra("kind", 0)
                val deadline = i.getLongExtra("deadline", 0L)
                if (kind == 7) {
                    Policy.sweepMissed(c)
                } else if (!Prefs.done(c, day, idx)) {
                    if (kind == 0) {
                        VoiceService.speak(c, "adhan", idx, 0)
                    } else {
                        val left = ((deadline - System.currentTimeMillis()) / 60000L).coerceAtLeast(1)
                        VoiceService.speak(c, "reminder", idx, left)
                    }
                    BlockActivity.show(c, "prayer")
                }
            }
        }
    }
}
