package com.me.blocker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

object Scheduler {
    private val REMINDERS = intArrayOf(5, 10, 20, 30, 45, 60)

    fun canExact(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms() else true

    fun rescheduleAll(c: Context) {
        val now = System.currentTimeMillis()
        for (off in -1..1) {
            for (p in PrayerTimes.day(c, off).prayers) {
                set(c, p, 0, p.start, now)
                REMINDERS.forEachIndexed { i, m ->
                    val t = p.start + m * 60000L
                    if (t < p.deadline - 60000L) set(c, p, i + 1, t, now)
                }
                set(c, p, 7, p.deadline, now)
            }
        }
        watchdog(c)
    }

    private fun set(c: Context, p: PrayerTimes.Prayer, kind: Int, at: Long, now: Long) {
        if (at <= now) return
        val i = Intent(c, PrayerAlarmReceiver::class.java)
            .setAction("PRAYER")
            .setData(Uri.parse("pray://${p.day}/${p.idx}/$kind"))
            .putExtra("idx", p.idx)
            .putExtra("day", p.day)
            .putExtra("kind", kind)
            .putExtra("start", p.start)
            .putExtra("deadline", p.deadline)
        val pi = PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        schedule(c, at, pi)
    }

    private fun watchdog(c: Context) {
        val i = Intent(c, PrayerAlarmReceiver::class.java).setAction("WATCHDOG")
        val pi = PendingIntent.getBroadcast(c, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        schedule(c, System.currentTimeMillis() + 15 * 60000L, pi)
    }

    private fun schedule(c: Context, at: Long, pi: PendingIntent) {
        val am = c.getSystemService(AlarmManager::class.java)
        try {
            if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}
