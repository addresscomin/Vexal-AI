package com.me.blocker

/** Voice lines. Urdu / Hindi / English depending on which TTS voice the phone has. */
object Messages {
    private val ur = arrayOf("فجر", "ظہر", "عصر", "مغرب", "عشاء")
    private val hi = arrayOf("फ़ज्र", "ज़ुहर", "अस्र", "मग़रिब", "इशा")
    private val en = arrayOf("Fajr", "Zuhr", "Asr", "Maghrib", "Isha")

    fun text(lang: String, kind: String, idx: Int, arg: Long): String = when (lang) {
        "ur" -> {
            val n = ur[idx]
            when (kind) {
                "adhan" -> if (idx == 0)
                    "فجر کی نماز کا وقت ہو گیا ہے۔ اٹھ جائیں، وضو کریں اور نماز پڑھیں۔ نماز نیند سے بہتر ہے۔"
                else "${n} کی نماز کا وقت ہو گیا ہے۔ فون رکھیں، وضو کریں اور نماز پڑھیں۔"
                "reminder" -> "${n} کی نماز ابھی تک نہیں پڑھی۔ صرف ${arg} منٹ باقی ہیں۔ فوراً نماز پڑھیں۔"
                "missed" -> "آپ نے ${n} کی نماز قضا کر دی ہے۔ سزا کے طور پر فون ${arg} منٹ کے لیے بند رہے گا۔"
                "done" -> "ماشاء اللہ، ${n} کی نماز پڑھ لی۔ فون کھول دیا گیا ہے۔"
                "limit" -> "آج کی فون کی حد پوری ہو گئی ہے۔ اب فون بند رہے گا۔ آرام کریں۔"
                else -> "آپ بہت دیر سے فون چلا رہے ہیں۔ ${arg} منٹ آنکھوں کو آرام دیں۔"
            }
        }
        "hi" -> {
            val n = hi[idx]
            when (kind) {
                "adhan" -> if (idx == 0)
                    "फ़ज्र की नमाज़ का वक़्त हो गया है। उठ जाइए, वुज़ू कीजिए और नमाज़ पढ़िए। नमाज़ नींद से बेहतर है।"
                else "${n} की नमाज़ का वक़्त हो गया है। फ़ोन रखिए, वुज़ू कीजिए और नमाज़ पढ़िए।"
                "reminder" -> "${n} की नमाज़ अभी तक नहीं पढ़ी। सिर्फ़ ${arg} मिनट बाक़ी हैं। फ़ौरन नमाज़ पढ़िए।"
                "missed" -> "आपने ${n} की नमाज़ क़ज़ा कर दी। सज़ा के तौर पर फ़ोन ${arg} मिनट के लिए बंद रहेगा।"
                "done" -> "माशा अल्लाह, ${n} की नमाज़ पढ़ ली। फ़ोन खोल दिया गया है।"
                "limit" -> "आज की फ़ोन की हद पूरी हो गई है। अब फ़ोन बंद रहेगा। आराम कीजिए।"
                else -> "आप बहुत देर से फ़ोन चला रहे हैं। ${arg} मिनट आँखों को आराम दीजिए।"
            }
        }
        else -> {
            val n = en[idx]
            when (kind) {
                "adhan" -> if (idx == 0)
                    "It is time for Fajr prayer. Wake up, make wudu and pray. Prayer is better than sleep."
                else "It is time for ${n} prayer. Put the phone down, make wudu and pray."
                "reminder" -> "You have not prayed ${n} yet. Only ${arg} minutes left. Pray now."
                "missed" -> "You missed ${n} prayer. The phone will stay locked for ${arg} minutes."
                "done" -> "Mashallah. ${n} prayer done. Phone unlocked."
                "limit" -> "Today's phone limit is finished. The phone will stay locked."
                else -> "You have been on the phone for a long time. Take a ${arg} minute break."
            }
        }
    }
}
