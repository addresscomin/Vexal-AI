package com.me.blocker

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) { Hardening.apply(context) }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Namaz Guard band karna apne aap se wada todna hai. Strict mode me ye phone reset tak band nahi hota."
}
