package com.me.blocker

import android.content.Context
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.*

/** Namaz times: Karachi method (Fajr 18, Isha 18), Hanafi Asr. */
object PrayerTimes {
    val NAMES = arrayOf("Fajr", "Zuhr", "Asr", "Maghrib", "Isha")

    data class Prayer(val idx: Int, val day: String, val start: Long, val deadline: Long)
    class Day(val prayers: List<Prayer>)

    private fun rad(d: Double) = Math.toRadians(d)
    private fun sinD(d: Double) = sin(rad(d))
    private fun cosD(d: Double) = cos(rad(d))
    private fun fixAngle(a: Double) = a - 360.0 * floor(a / 360.0)
    private fun fixHour(a: Double) = a - 24.0 * floor(a / 24.0)

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0
        var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    private fun sunPos(jd: Double): DoubleArray {
        val dd = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * dd)
        val q = fixAngle(280.459 + 0.98564736 * dd)
        val l = fixAngle(q + 1.915 * sinD(g) + 0.020 * sinD(2 * g))
        val e = 23.439 - 0.00000036 * dd
        val ra = Math.toDegrees(atan2(cosD(e) * sinD(l), cosD(l))) / 15.0
        val eqt = q / 15.0 - fixHour(ra)
        val decl = Math.toDegrees(asin(sinD(e) * sinD(l)))
        return doubleArrayOf(decl, eqt)
    }

    private fun times(jd0: Double, lat: Double, lng: Double, tz: Double): DoubleArray {
        val jd = jd0 - lng / (15.0 * 24.0)
        fun midDay(t: Double): Double = fixHour(12.0 - sunPos(jd + t)[1])
        fun sunAngleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sunPos(jd + t)[0]
            val noon = midDay(t)
            val x = (-sinD(angle) - sinD(decl) * sinD(lat)) / (cosD(decl) * cosD(lat))
            val tt = Math.toDegrees(acos(x.coerceIn(-1.0, 1.0))) / 15.0
            return noon + (if (ccw) -tt else tt)
        }
        fun asrTime(factor: Double, t: Double): Double {
            val decl = sunPos(jd + t)[0]
            val angle = -Math.toDegrees(atan(1.0 / (factor + tan(rad(abs(lat - decl))))))
            return sunAngleTime(angle, t, false)
        }
        val fajr = sunAngleTime(18.0, 5.0 / 24, true)
        val sunrise = sunAngleTime(0.833, 6.0 / 24, true)
        val dhuhr = midDay(12.0 / 24)
        val asr = asrTime(2.0, 13.0 / 24)
        val sunset = sunAngleTime(0.833, 18.0 / 24, false)
        val isha = sunAngleTime(18.0, 18.0 / 24, false)
        val adj = tz - lng / 15.0
        return doubleArrayOf(
            fajr + adj, sunrise + adj, dhuhr + adj + 1 / 60.0,
            asr + adj, sunset + adj + 1 / 60.0, isha + adj
        )
    }

    private fun midnight(offset: Int): Long {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, offset)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun minutesOfDay(ms: Long): Int {
        val cal = Calendar.getInstance(); cal.timeInMillis = ms
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    /** Sirf calculation (location se) wale 5 waqt, minutes-of-day me. */
    fun calcMinutes(c: Context): IntArray {
        val d = day(c, 0, false)
        return IntArray(5) { minutesOfDay(d.prayers[it].start) }
    }

    /** Abhi jo waqt chal rahe hain (manual saved ho to wahi, warna calculated). */
    fun currentMinutes(c: Context): IntArray = Prefs.manualTimes(c) ?: calcMinutes(c)

    /** offset = 0 today, 1 tomorrow, -1 yesterday */
    fun day(c: Context, offset: Int, useManual: Boolean = true): Day {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, offset)
        val start = midnight(offset)
        val tz = TimeZone.getDefault().getOffset(start + 12 * 3600000L) / 3600000.0
        val jd = julian(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        val t = times(jd, Prefs.lat(c), Prefs.lng(c), tz)
        fun ms(h: Double, fb: Double): Long = start + ((if (h.isNaN()) fb else h) * 3600000.0).toLong()
        val sunrise = ms(t[1], 6.5)
        val calc = longArrayOf(ms(t[0], 5.0), ms(t[2], 12.2), ms(t[3], 15.5), ms(t[4], 18.0), ms(t[5], 19.5))
        val manual = if (useManual) Prefs.manualTimes(c) else null
        val starts = if (manual != null) LongArray(5) { start + manual[it] * 60000L } else calc
        val key = Prefs.dayKey(start)
        val ends = longArrayOf(sunrise, starts[2], starts[3], starts[4], starts[4] + 4 * 3600000L)
        val win = Prefs.windowMin(c) * 60000L
        val list = (0..4).map { i ->
            val raw = minOf(ends[i], starts[i] + win)
            Prayer(i, key, starts[i], maxOf(raw, starts[i] + 10 * 60000L))
        }
        return Day(list)
    }

    /** Prayer whose window is open now and not yet confirmed. */
    fun active(c: Context, now: Long = System.currentTimeMillis()): Prayer? {
        for (off in -1..0) {
            for (p in day(c, off).prayers) {
                if (now >= p.start && now < p.deadline && !Prefs.done(c, p.day, p.idx)) return p
            }
        }
        return null
    }

    fun next(c: Context, now: Long = System.currentTimeMillis()): Prayer? {
        for (off in 0..1) {
            for (p in day(c, off).prayers) if (p.start > now) return p
        }
        return null
    }
}
