package com.me.blocker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/**
 * mode = "block": tick = hamesha block (strict me unblock nahi hota).
 * mode = "allow": tick = lock/namaz ke waqt bhi khula (WhatsApp call/msg jaisa). Strict me naya allow add nahi hota.
 */
class AppPickerActivity : Activity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b) }

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this) && Policy.ownScreenReason(this) != null) {
            BlockActivity.show(this, "locked"); finish(); return
        }
        build()
    }

    private fun build() {
        val allowMode = intent?.getStringExtra("mode") == "allow"
        val pm = packageManager
        val sys = Policy.alwaysAllowed(this)
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .distinctBy { it.first }
            .filter { it.first != packageName && (allowMode || !sys.contains(it.first)) }
            .sortedBy { it.second.lowercase() }

        fun fixed(pkg: String) = Policy.HARD.contains(pkg) || Policy.isGame(this, pkg)
        fun stored(): Set<String> = if (allowMode) Prefs.allowedLock(this) else Prefs.custom(this)
        fun save(s: Set<String>) { if (allowMode) Prefs.setAllowedLock(this, s) else Prefs.setCustom(this, s) }

        val labels = apps.map {
            when {
                !allowMode && fixed(it.first) -> it.second + "  (pehle se block)"
                allowMode && (fixed(it.first) || Prefs.custom(this).contains(it.first)) -> it.second + "  (block list me)"
                else -> it.second
            }
        }
        val list = ListView(this)
        list.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, labels)
        val chosen = stored()
        for ((i, a) in apps.withIndex()) {
            if ((!allowMode && fixed(a.first)) || chosen.contains(a.first)) list.setItemChecked(i, true)
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].first
            val on = list.isItemChecked(pos)
            if (!allowMode && fixed(pkg)) {
                list.setItemChecked(pos, true)
                Toast.makeText(this, "Ye app pehle se hamesha block hai.", Toast.LENGTH_SHORT).show()
                return@setOnItemClickListener
            }
            if (allowMode && on && (fixed(pkg) || Prefs.custom(this).contains(pkg))) {
                list.setItemChecked(pos, false)
                Toast.makeText(this, "Block list wale app allow nahi ho sakte.", Toast.LENGTH_SHORT).show()
                return@setOnItemClickListener
            }
            if (Prefs.strict(this)) {
                // strict me block list sirf badh sakti hai, allow list sirf ghat sakti hai
                if (!allowMode && !on && Prefs.custom(this).contains(pkg)) {
                    list.setItemChecked(pos, true)
                    Toast.makeText(this, "Strict mode me unblock nahi kar sakte.", Toast.LENGTH_LONG).show()
                    return@setOnItemClickListener
                }
                if (allowMode && on && !Prefs.allowedLock(this).contains(pkg)) {
                    list.setItemChecked(pos, false)
                    Toast.makeText(this, "Strict mode me naya app allow nahi kar sakte.", Toast.LENGTH_LONG).show()
                    return@setOnItemClickListener
                }
            }
            val s = HashSet(stored())
            if (on) s.add(pkg) else s.remove(pkg)
            save(s)
        }

        val head = TextView(this).apply {
            text = if (allowMode) "Tick = lock / namaz ke waqt bhi khula rahega\n(WhatsApp call/msg jaisa. Strict me naya add nahi hota)"
            else "Tick = hamesha block\n(Strict ON me unblock nahi hoga)"
            textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(24, 48, 24, 24)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0B10"))
        }
        root.addView(head)
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
