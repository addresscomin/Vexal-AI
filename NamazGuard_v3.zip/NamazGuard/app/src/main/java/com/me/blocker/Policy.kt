package com.me.blocker

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.provider.Telephony
import android.telecom.TelecomManager
import android.view.inputmethod.InputMethodManager
import java.util.Calendar

object Policy {

    /** Hamesha block: social media, short video, streaming, dating, games. Yahan edit karo. */
    val HARD = setOf(
        "com.instagram.android", "com.instagram.lite",
        "com.facebook.katana", "com.facebook.lite",
        "com.zhiliaoapp.musically", "com.zhiliaoapp.musically.go",
        "com.ss.android.ugc.trill", "com.ss.android.ugc.aweme",
        "com.snapchat.android", "com.twitter.android", "com.reddit.frontpage",
        "com.pinterest", "com.netflix.mediaclient", "tv.twitch.android.app",
        "video.like", "video.like.lite", "sg.bigo.live", "com.kwai.video", "com.smile.gifmaker",
        "com.google.android.youtube", "com.vanced.android.youtube",
        "com.tinder", "com.badoo.mobile", "com.discord",
        "com.amazon.avod.thirdpartyclient", "com.disney.disneyplus", "in.startv.hotstar",
        "com.tencent.ig", "com.dts.freefireth", "com.activision.callofduty.shooter",
        "com.garena.game.codm", "com.supercell.clashofclans", "com.supercell.brawlstars",
        "com.mojang.minecraftpe", "com.roblox.client", "com.epicgames.fortnite",
        "com.kiloo.subwaysurf", "com.king.candycrushsaga"
    )

    /** Strict mode me ye bhi block: settings (admin/accessibility band karne se rokne ke liye) aur installer. */
    val TAMPER = setOf(
        "com.android.settings", "com.google.android.packageinstaller",
        "com.android.packageinstaller", "com.samsung.android.packageinstaller",
        "com.android.settings.intelligence", "com.google.android.settings.intelligence",
        "com.android.vending",                 // Play Store se uninstall band
        "com.google.android.gms.setupservices"
    )

    private val ALWAYS = setOf(
        "com.android.systemui", "android", "com.android.phone", "com.android.server.telecom",
        "com.android.incallui", "com.android.dialer", "com.google.android.dialer",
        "com.samsung.android.dialer", "com.samsung.android.incallui",
        "com.android.contacts", "com.google.android.contacts", "com.samsung.android.app.contacts",
        "com.android.emergency", "com.google.android.apps.messaging",
        "com.samsung.android.messaging", "com.android.mms", "com.android.providers.telephony"
    )

    private val KEYWORDS = listOf("quran", "muslim", "islam", "salah", "hadith", "athan", "adhan", "prayer")

    const val MIN_PRAYER_MS = 5 * 60000L

    fun invalidate() { cacheAt = 0L }

    private var camAt = 0L
    private var camCache: Set<String> = emptySet()
    fun cameraPkgs(c: Context): Set<String> {
        val now = System.currentTimeMillis()
        if (now - camAt < 60000 && camCache.isNotEmpty()) return camCache
        camCache = try {
            c.packageManager.queryIntentActivities(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 0)
                .map { it.activityInfo.packageName }.toSet()
        } catch (e: Exception) { emptySet() }
        camAt = now
        return camCache
    }

    private var cacheAt = 0L
    private var cache: Set<String> = emptySet()

    fun alwaysAllowed(c: Context): Set<String> {
        val now = System.currentTimeMillis()
        if (now - cacheAt < 60000 && cache.isNotEmpty()) return cache
        val s = HashSet<String>(ALWAYS)
        s.add(c.packageName)
        try { (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { s.add(it) } } catch (e: Exception) {}
        try { Telephony.Sms.getDefaultSmsPackage(c)?.let { s.add(it) } } catch (e: Exception) {}
        try {
            val imm = c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            for (m in imm.enabledInputMethodList) s.add(m.packageName)
        } catch (e: Exception) {}
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            c.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { s.add(it) }
        } catch (e: Exception) {}
        cache = s
        cacheAt = now
        return s
    }

    @Suppress("DEPRECATION")
    fun isGame(c: Context, pkg: String): Boolean = try {
        val ai = c.packageManager.getApplicationInfo(pkg, 0)
        ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    } catch (e: Exception) { false }

    private fun keywordAllowed(pkg: String): Boolean {
        val p = pkg.lowercase()
        return KEYWORDS.any { p.contains(it) }
    }

    /** null = allow, else reason: hard / tamper / prayer / locked */
    fun block(c: Context, pkg: String?): String? {
        if (pkg == null || !Prefs.armed(c)) return null
        if (pkg == c.packageName) return null
        val now = System.currentTimeMillis()
        // namaz ka saboot (live photo) lete waqt sirf camera app ko ijazat
        if (Prefs.long(c, "proofUntil") > now && cameraPkgs(c).contains(pkg)) return null
        if (alwaysAllowed(c).contains(pkg)) return null
        if (HARD.contains(pkg) || Prefs.custom(c).contains(pkg) || isGame(c, pkg)) return "hard"
        if (Prefs.strict(c) && TAMPER.contains(pkg)) return "tamper"
        if (Prefs.allowedLock(c).contains(pkg)) return null
        if (PrayerTimes.active(c, now) != null) return "prayer"
        if (Prefs.lockUntil(c) > now) {
            // namaz qaza ki saza me POORA phone band; limit/break me sirf Quran/Islamic apps
            return if (Prefs.lockReason(c) != "missed" && keywordAllowed(pkg)) null else "locked"
        }
        return null
    }

    /** Reason for our own full-screen lock, or null if phone is free. */
    fun ownScreenReason(c: Context): String? {
        if (!Prefs.armed(c)) return null
        val now = System.currentTimeMillis()
        if (PrayerTimes.active(c, now) != null) return "prayer"
        if (Prefs.lockUntil(c) > now) return "locked"
        return null
    }

    /** Deadline guzar gayi aur namaz confirm nahi hui to saza lagao. */
    fun sweepMissed(c: Context) {
        if (!Prefs.armed(c)) return
        val now = System.currentTimeMillis()
        for (off in -1..0) {
            for (p in PrayerTimes.day(c, off).prayers) {
                if (p.start < Prefs.armedAt(c)) continue
                if (now < p.deadline) continue
                if (Prefs.done(c, p.day, p.idx) || Prefs.missed(c, p.day, p.idx)) continue
                Prefs.setMissed(c, p.day, p.idx)
                val n = Prefs.bumpMissed(c, p.day)
                val minutes = if (n >= 5) 1440 else 60 + 30 * (n - 1)   // 1 qaza = 60 min, har agli +30, paanchon = 24 ghante
                val until = p.deadline + minutes * 60000L
                if (until > Prefs.lockUntil(c)) Prefs.setLock(c, until, "missed")
                if (until > now) VoiceService.speak(c, "missed", p.idx, (until - now) / 60000L)
            }
        }
    }

    fun endOfDay(): Long {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun adminActive(c: Context): Boolean {
        val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(ComponentName(c, AdminReceiver::class.java))
    }
}
