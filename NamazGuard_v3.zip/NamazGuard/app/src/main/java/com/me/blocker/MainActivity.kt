package com.me.blocker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var col: LinearLayout

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this) && Policy.ownScreenReason(this) != null) {
            BlockActivity.show(this, "locked")
            finish()
            return
        }
        Hardening.apply(this)
        render()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun d(v: Int) = Ui.dp(this, v)

    private fun accOn(): Boolean {
        val flat = ComponentName(this, BlockerAccessibilityService::class.java).flattenToString()
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(flat)
    }

    private fun isHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == packageName
    }

    private fun open(a: String, pkg: Boolean = true) {
        try {
            val i = Intent(a)
            if (pkg) i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (e: Exception) { toast("Ye screen nahi khuli") }
    }

    // ---------- small UI builders ----------
    private fun section(t: String) {
        col.addView(Ui.text(this, t.uppercase(), 12f, Ui.SUB).apply { setPadding(d(16), 0, 0, d(6)) }, Ui.lp(this, 22))
    }

    private fun card(): LinearLayout { val c = Ui.card(this); col.addView(c, Ui.lp(this)); return c }

    private fun row(parent: LinearLayout, left: String, right: String, rightColor: Int = Ui.SUB, onClick: (() -> Unit)? = null) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, d(12), 0, d(12))
        }
        r.addView(Ui.text(this, left, 16f), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(Ui.text(this, right, 16f, rightColor))
        if (onClick != null) r.setOnClickListener { onClick() }
        parent.addView(r)
        parent.addView(View(this).apply { setBackgroundColor(Ui.SEP) }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
    }

    private fun perm(parent: LinearLayout, name: String, ok: Boolean, action: () -> Unit) {
        row(parent, name, if (ok) "✅" else "Allow karo", if (ok) Ui.GREEN else Ui.BLUE) { if (!ok) action() }
    }

    private fun field(parent: LinearLayout, label: String, value: String, decimal: Boolean = false): EditText {
        parent.addView(Ui.text(this, label, 13f, Ui.SUB).apply { setPadding(0, d(10), 0, 0) })
        val e = EditText(this)
        e.setText(value)
        e.inputType = if (decimal) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        else InputType.TYPE_CLASS_NUMBER
        parent.addView(e)
        return e
    }

    private fun fmtMin(m: Int): String {
        val h = m / 60; val mm = m % 60
        val h12 = if (h % 12 == 0) 12 else h % 12
        return String.format(Locale.US, "%d:%02d %s", h12, mm, if (h < 12) "AM" else "PM")
    }

    // ---------- screen ----------
    private fun render() {
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(48), d(16), d(48)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        sv.addView(col)
        setContentView(sv)

        val armed = Prefs.armed(this)
        val strict = Prefs.strict(this)
        val owner = Hardening.isOwner(this)

        col.addView(Ui.text(this, "Namaz Guard", 34f, Ui.LABEL, true).apply { setPadding(d(4), 0, 0, 0) })

        val st = card()
        row(st, "Guard", if (armed) "ON ✅" else "OFF")
        row(st, "Strict mode", if (strict) "ON 🔒 (lifetime)" else "OFF")
        row(st, "Lifetime protection (Device Owner)", if (owner) "✅" else "❌", if (owner) Ui.GREEN else Ui.RED)
        row(st, "Aaj phone", "${Prefs.used(this) / 60000L} / ${Prefs.limitMin(this)} min")
        row(st, "Namaz saboot (photo)", "${Prefs.int(this, "proofCount", 0)} jama")

        // ---- namaz times (edit + save) ----
        section("Namaz ke waqt (tap karke badlo)")
        val tc = card()
        val cur = PrayerTimes.currentMinutes(this)
        for (i in 0..4) {
            row(tc, PrayerTimes.NAMES[i], fmtMin(cur[i]), Ui.BLUE) { editTime(i, cur[i]) }
        }
        tc.addView(Ui.text(this,
            if (Prefs.manualTimes(this) != null) "Aapke save kiye hue waqt chal rahe hain." else "Abhi location se calculated waqt chal rahe hain. Koi waqt badloge to saare 5 waqt save ho jayenge.",
            12f, Ui.SUB).apply { setPadding(0, d(8), 0, d(4)) })
        if (Prefs.manualTimes(this) != null) {
            tc.addView(Ui.pill(this, "Calculated waqt par wapas", Ui.BG, Ui.BLUE) {
                if (PrayerTimes.active(this) != null) toast("Namaz ke waqt ye nahi badal sakte.")
                else { Prefs.clearManualTimes(this); Scheduler.rescheduleAll(this); render() }
            }, Ui.lp(this, 6))
        }
        if (strict) tc.addView(Ui.text(this, "Strict: waqt calculated se sirf ±30 min tak badal sakte ho.", 12f, Ui.SUB))

        // ---- permissions ----
        section("Permissions")
        val pc = card()
        val nm = getSystemService(PowerManager::class.java)
        perm(pc, "Notifications", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        perm(pc, "Exact alarm", Scheduler.canExact(this)) {
            if (Build.VERSION.SDK_INT >= 31) open(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        }
        perm(pc, "Display over other apps", Settings.canDrawOverlays(this)) { open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) }
        perm(pc, "Accessibility (block engine)", accOn()) { open(Settings.ACTION_ACCESSIBILITY_SETTINGS, false) }
        perm(pc, "Device Admin (phone lock)", Policy.adminActive(this)) {
            try {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Phone lock ke liye"))
            } catch (e: Exception) { toast("Admin screen nahi khuli") }
        }
        perm(pc, "Battery optimization band", nm.isIgnoringBatteryOptimizations(packageName)) {
            open(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        }
        perm(pc, "Location (sahi namaz time)", checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2)
        }
        perm(pc, "Namaz Home = default launcher", isHome()) { open(Settings.ACTION_HOME_SETTINGS, false) }

        if (!owner) {
            pc.addView(Ui.text(this,
                "Uninstall/disable se POORI suraksha ke liye Device Owner chahiye (Android me normal app ko ye haq nahi milta). PC se ek baar:\n\nadb shell dpm set-device-owner com.me.blocker/.AdminReceiver\n\n(Pehle phone se saare Google/other accounts hatao, phir command chalao, phir accounts wapas jodo.)",
                12f, Ui.SUB).apply { setPadding(0, d(10), 0, d(6)); setTextIsSelectable(true) })
        }

        // ---- apps ----
        section("Apps")
        val ac = card()
        ac.addView(Ui.pill(this, "📵 Block karne wale apps chuno", Ui.BLUE, Color.WHITE) {
            startActivity(Intent(this, AppPickerActivity::class.java).putExtra("mode", "block"))
        }, Ui.lp(this, 6))
        ac.addView(Ui.pill(this, "✅ Lock me bhi khule apps (WhatsApp jaisa)", Ui.BG, Ui.BLUE) {
            startActivity(Intent(this, AppPickerActivity::class.java).putExtra("mode", "allow"))
        }, Ui.lp(this, 10))
        ac.addView(View(this), Ui.lp(this, 6))

        // ---- settings ----
        section("Limits")
        val sc = card()
        val etLimit = field(sc, "Roz ki phone limit (min) — itne ke baad sab band", Prefs.limitMin(this).toString())
        val etSession = field(sc, "Lagatar use limit (min)", Prefs.sessionMin(this).toString())
        val etBreak = field(sc, "Break (min)", Prefs.breakMin(this).toString())
        val etWin = field(sc, "Namaz ki deadline (waqt shuru se kitne min)", Prefs.windowMin(this).toString())
        val etLat = field(sc, "Latitude", Prefs.lat(this).toString(), true)
        val etLng = field(sc, "Longitude", Prefs.lng(this).toString(), true)
        sc.addView(Ui.pill(this, "💾 Save", Ui.BLUE, Color.WHITE) {
            val l = (etLimit.text.toString().toIntOrNull() ?: Prefs.limitMin(this)).coerceIn(30, 720)
            val s = (etSession.text.toString().toIntOrNull() ?: Prefs.sessionMin(this)).coerceIn(10, 240)
            val b = (etBreak.text.toString().toIntOrNull() ?: Prefs.breakMin(this)).coerceIn(1, 120)
            val w = (etWin.text.toString().toIntOrNull() ?: Prefs.windowMin(this)).coerceIn(30, 180)
            if (Prefs.strict(this) && (l > Prefs.limitMin(this) || s > Prefs.sessionMin(this) || b < Prefs.breakMin(this) || w > Prefs.windowMin(this))) {
                toast("Strict mode me limit dheeli nahi kar sakte.")
            } else {
                Prefs.setInt(this, "limit", l); Prefs.setInt(this, "session", s); Prefs.setInt(this, "break", b); Prefs.setInt(this, "window", w)
                if (!Prefs.strict(this)) {
                    Prefs.setStr(this, "lat", etLat.text.toString()); Prefs.setStr(this, "lng", etLng.text.toString())
                }
                Scheduler.rescheduleAll(this)
                toast("Save ho gaya")
                render()
            }
        }, Ui.lp(this, 14))
        sc.addView(Ui.pill(this, "📍 Meri location se set karo", Ui.BG, Ui.BLUE) { useLocation() }, Ui.lp(this, 10))
        sc.addView(Ui.pill(this, "🔊 Awaaz test", Ui.BG, Ui.BLUE) { VoiceService.speak(this, "adhan", 1, 0) }, Ui.lp(this, 10))
        sc.addView(View(this), Ui.lp(this, 6))

        // ---- guard control ----
        section("Guard control")
        val gc = card()
        if (!armed) {
            gc.addView(Ui.pill(this, "✅ Guard ON karo", Ui.GREEN, Color.BLACK) {
                Prefs.setArmed(this, true)
                Scheduler.rescheduleAll(this)
                BlockerService.start(this)
                render()
            }, Ui.lp(this, 6))
        } else if (!strict) {
            gc.addView(Ui.pill(this, "🔒 Strict mode ON (lifetime)", Ui.RED, Color.WHITE) { confirmStrict() }, Ui.lp(this, 6))
            gc.addView(Ui.pill(this, "Guard OFF", Ui.BG, Ui.RED) { Prefs.setArmed(this, false); render() }, Ui.lp(this, 10))
        } else {
            gc.addView(Ui.text(this,
                "Strict mode lifetime ON hai. Guard/Strict ko band karne ka koi button nahi hai — ye sirf phone factory reset hone par jayega.",
                14f, Ui.SUB).apply { setPadding(0, d(10), 0, d(10)) })
        }
        gc.addView(View(this), Ui.lp(this, 6))
        col.addView(Ui.text(this, "Pehle saari permissions, phir Guard ON, aakhir me Strict ON.", 12f, Ui.SUB).apply { setPadding(d(4), d(14), 0, 0) })
    }

    private fun editTime(i: Int, curMin: Int) {
        if (PrayerTimes.active(this) != null) { toast("Namaz ke waqt time nahi badal sakte."); return }
        TimePickerDialog(this, { _, hh, mm ->
            val v = hh * 60 + mm
            val calc = PrayerTimes.calcMinutes(this)[i]
            if (Prefs.strict(this) && abs(v - calc) > 30) {
                toast("Strict mode me calculated waqt (${fmtMin(calc)}) se sirf ±30 min tak badal sakte ho.")
            } else {
                val arr = PrayerTimes.currentMinutes(this).copyOf()
                arr[i] = v
                Prefs.setManualTimes(this, arr)
                Scheduler.rescheduleAll(this)
                toast("${PrayerTimes.NAMES[i]} ka waqt save ho gaya")
                render()
            }
        }, curMin / 60, curMin % 60, false).show()
    }

    private fun confirmStrict() {
        if (!accOn() || !Policy.adminActive(this)) {
            toast("Pehle Accessibility aur Device Admin allow karo."); return
        }
        val et = EditText(this).apply { hint = "STRICT likho" }
        AlertDialog.Builder(this)
            .setTitle("Strict mode: wapas nahi hoga")
            .setMessage("ON karne ke baad Guard/Strict band nahi honge, Settings block rahengi, limit sirf kadi ho sakti hai." +
                (if (Hardening.isOwner(this)) " App uninstall/disable sirf phone factory reset se hoga." else " (Device Owner nahi hai, isliye uninstall protection kamzor rahegi.)") +
                "\n\nPakka ho to neeche STRICT likho.")
            .setView(et)
            .setPositiveButton("ON karo") { _, _ ->
                if (et.text.toString().trim().uppercase() == "STRICT") {
                    Prefs.setStrict(this, true)
                    Hardening.apply(this)
                    render()
                } else toast("STRICT nahi likha, cancel.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun useLocation() {
        if (Prefs.strict(this)) { toast("Strict mode me location nahi badal sakte."); return }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2); return
        }
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
                .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
                .maxByOrNull { it.time }
            if (loc == null) {
                toast("Location nahi mili. GPS on karke Maps kholo, phir dobara try karo.")
            } else {
                Prefs.setStr(this, "lat", loc.latitude.toString())
                Prefs.setStr(this, "lng", loc.longitude.toString())
                Scheduler.rescheduleAll(this)
                toast("Location set ho gayi")
                render()
            }
        } catch (e: Exception) { toast("Location error") }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        render()
    }
}
