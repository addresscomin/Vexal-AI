package com.me.blocker

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sqrt

/**
 * Namaz ka saboot: tick nahi chalega. Camera se LIVE photo (gallery se nahi) leni hoti hai,
 * blank/andhera photo reject hoti hai, aur photo app me save hoti hai (filesDir/proofs).
 */
class ProofActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = PrayerTimes.active(this)
        if (p == null || System.currentTimeMillis() < p.start + Policy.MIN_PRAYER_MS) { finish(); return }
        Prefs.setLong(this, "proofUntil", System.currentTimeMillis() + 4 * 60000L)
        Hardening.syncLockTask(this)
        try {
            startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 77)
        } catch (e: Exception) {
            Prefs.setLong(this, "proofUntil", 0L)
            Toast.makeText(this, "Camera nahi khula", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        Prefs.setLong(this, "proofUntil", 0L)
        val p = PrayerTimes.active(this)
        if (res != RESULT_OK || p == null) { toast("Saboot nahi mila. Namaz tasdeeq nahi hui."); finish(); return }

        val bmp = data?.extras?.get("data") as? Bitmap
        if (bmp != null && !looksReal(bmp)) { toast("Photo blank/andheri hai. Janamaz ki saaf photo lo."); finish(); return }
        try {
            if (bmp != null) {
                val dir = File(filesDir, "proofs"); dir.mkdirs()
                FileOutputStream(File(dir, "${p.day}_${p.idx}.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            }
        } catch (e: Exception) {}
        Prefs.setDone(this, p.day, p.idx)
        Prefs.setInt(this, "proofCount", Prefs.int(this, "proofCount", 0) + 1)
        VoiceService.stop(this)
        VoiceService.speak(this, "done", p.idx, 0)
        finish()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    /** Dhakka hua lens / poora kaala / poora ek rang = reject. */
    private fun looksReal(b: Bitmap): Boolean {
        return try {
            val s = Bitmap.createScaledBitmap(b, 16, 16, true)
            var sum = 0.0; var sq = 0.0
            for (x in 0 until 16) for (y in 0 until 16) {
                val px = s.getPixel(x, y)
                val l = 0.299 * ((px shr 16) and 255) + 0.587 * ((px shr 8) and 255) + 0.114 * (px and 255)
                sum += l; sq += l * l
            }
            val mean = sum / 256.0
            sqrt(sq / 256.0 - mean * mean) > 10.0 && mean > 15.0
        } catch (e: Exception) { true }
    }
}
