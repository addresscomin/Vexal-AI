package com.me.blocker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context

object Notif {
    fun ensure(c: Context, id: String, name: String) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(id, name, NotificationManager.IMPORTANCE_LOW))
    }

    fun build(c: Context, channel: String, title: String, text: String): Notification {
        ensure(c, channel, channel)
        return Notification.Builder(c, channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .build()
    }
}
