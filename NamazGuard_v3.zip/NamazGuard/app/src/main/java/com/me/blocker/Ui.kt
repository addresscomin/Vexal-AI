package com.me.blocker

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** iOS jaisa look: grouped cards, rounded pills, SF-style colors. */
object Ui {
    val BLUE = Color.parseColor("#0A84FF")
    val RED = Color.parseColor("#FF453A")
    val GREEN = Color.parseColor("#30D158")
    val BG = Color.parseColor("#F2F2F7")
    val CARD = Color.WHITE
    val LABEL = Color.BLACK
    val SUB = Color.parseColor("#8E8E93")
    val SEP = Color.parseColor("#E5E5EA")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(color: Int, radiusPx: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radiusPx }

    fun text(c: Context, t: String, sp: Float, color: Int = LABEL, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = t; textSize = sp; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    fun pill(c: Context, t: String, bg: Int, fg: Int, onClick: () -> Unit): TextView =
        TextView(c).apply {
            text = t; textSize = 16f; setTextColor(fg); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(bg, dp(c, 14).toFloat())
            setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
            isClickable = true
            setOnClickListener { onClick() }
        }

    fun card(c: Context): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, dp(c, 14).toFloat())
            setPadding(dp(c, 16), dp(c, 8), dp(c, 16), dp(c, 8))
        }

    fun lp(c: Context, top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(c, top) }
}
