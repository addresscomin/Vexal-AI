package com.me.blocker

import android.app.KeyguardManager
import android.app.NotificationManager
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BlockerService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var lastActive = 0L
    private var blockSince = 0L
    private var ticks = 0

    private val loop = object : Runnable {
        override fun run() {
            try { tick() } catch (e: Throwable) {}
            h.postDelayed(this, TICK)
        }
    }

    companion object {
        const val TICK = 5000L
        fun start(c: Context) {
            try { c.startForegroundService(Intent(c, BlockerService::class.java)) } catch (e: Exception) {}
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startFg("Guard chal raha hai")
        h.post(loop)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        startFg("Guard chal raha hai")
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // "Close all" / recents se swipe karne par bhi guard dobara chalu
        start(this)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        h.removeCallbacks(loop)
        super.onDestroy()
    }

    private fun startFg(text: String) {
        val n = Notif.build(this, "guard", "Namaz Guard", text)
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun tick() {
        if (!Prefs.armed(this)) return
        val now = System.currentTimeMillis()
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        val interactive = pm.isInteractive && !km.isKeyguardLocked
        val pkg = BlockerAccessibilityService.currentPkg

        Policy.sweepMissed(this)

        // ---- Device Owner hardening: status bar / lock-task whitelist ----
        if (Hardening.isOwner(this)) {
            Hardening.statusBar(this, Policy.ownScreenReason(this) != null)
            Hardening.syncLockTask(this)
        }

        // ---- usage counting ----
        val free = pkg != null && Policy.alwaysAllowed(this).contains(pkg) && pkg != packageName
        if (interactive && !free) {
            lastActive = now
            Prefs.addUsed(this, TICK)
            val s = Prefs.long(this, "session") + TICK
            Prefs.setLong(this, "session", s)
            if (s >= Prefs.sessionMin(this) * 60000L) {
                Prefs.setLong(this, "session", 0L)
                Prefs.setLock(this, now + Prefs.breakMin(this) * 60000L, "break")
                VoiceService.speak(this, "break", 0, Prefs.breakMin(this).toLong())
            }
        } else if (!interactive && lastActive != 0L && now - lastActive > 180000L) {
            Prefs.setLong(this, "session", 0L)
        }

        // ---- daily limit ----
        val today = Prefs.dayKey()
        if (Prefs.used(this) >= Prefs.limitMin(this) * 60000L && Prefs.str(this, "limitDay") != today) {
            Prefs.setStr(this, "limitDay", today)
            Prefs.setLock(this, Policy.endOfDay(), "limit")
            VoiceService.speak(this, "limit", 0, 0)
        }

        // ---- enforce on current app ----
        if (interactive && pkg != null) {
            val r = Policy.block(this, pkg)
            if (r != null) BlockActivity.show(this, r)
        }
        val ownReason = Policy.ownScreenReason(this)
        if (ownReason == "prayer" && interactive && !BlockActivity.visible && pkg != null && pkg != "com.android.systemui" &&
            Prefs.long(this, "proofUntil") < now) {
            // namaz ke waqt screen par hamesha lock screen dikhao (apps ke ilawa home par bhi)
            if (!Policy.alwaysAllowed(this).contains(pkg) || pkg == packageName) BlockActivity.show(this, "prayer")
        }

        // ---- hard lock: lock screen 25 sec se zyada khuli rahe to screen band ----
        if (BlockActivity.visible && interactive && ownReason == "locked") {
            if (blockSince == 0L) blockSince = now
            else if (now - blockSince > 25000L) {
                blockSince = 0L
                try {
                    val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                    if (dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))) dpm.lockNow()
                } catch (e: Exception) {}
            }
        } else blockSince = 0L

        // ---- notification text (har minute) ----
        ticks++
        if (ticks % 12 == 1) {
            val next = PrayerTimes.next(this, now)
            val t = if (next != null)
                "Agli: ${PrayerTimes.NAMES[next.idx]} ${SimpleDateFormat("hh:mm a", Locale.US).format(Date(next.start))}"
            else "Guard chal raha hai"
            val usedMin = Prefs.used(this) / 60000L
            getSystemService(NotificationManager::class.java)
                .notify(1, Notif.build(this, "guard", "Namaz Guard  •  $usedMin/${Prefs.limitMin(this)} min", t))
        }
    }
}
