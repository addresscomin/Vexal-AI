package com.me.blocker

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("guard", Context.MODE_PRIVATE)

    fun long(c: Context, k: String, d: Long = 0L): Long = sp(c).getLong(k, d)
    fun setLong(c: Context, k: String, v: Long) { sp(c).edit().putLong(k, v).apply() }
    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    fun bool(c: Context, k: String, d: Boolean = false): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun str(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }

    fun dayKey(ms: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))

    // ---- guard state ----
    fun armed(c: Context) = bool(c, "armed")
    fun armedAt(c: Context) = long(c, "armedAt")
    fun setArmed(c: Context, on: Boolean) {
        if (!on && strict(c)) return          // strict ON hone ke baad guard band nahi hota
        setBool(c, "armed", on)
        if (on) setLong(c, "armedAt", System.currentTimeMillis())
    }
    fun strict(c: Context) = bool(c, "strict")
    fun setStrict(c: Context, on: Boolean) {
        if (!on && strict(c)) return          // lifetime: strict wapas OFF nahi hota (phone reset tak)
        setBool(c, "strict", on)
    }

    // ---- settings ----
    fun lat(c: Context): Double = str(c, "lat", "24.8607").toDoubleOrNull() ?: 24.8607
    fun lng(c: Context): Double = str(c, "lng", "67.0011").toDoubleOrNull() ?: 67.0011
    fun limitMin(c: Context) = int(c, "limit", 180)
    fun sessionMin(c: Context) = int(c, "session", 45)
    fun breakMin(c: Context) = int(c, "break", 10)
    fun windowMin(c: Context) = int(c, "window", 90)

    // ---- manual (saved) namaz times: minutes of day x5, ek baar save = hamesha wahi ----
    fun manualTimes(c: Context): IntArray? {
        val s = str(c, "manual", "")
        if (s.isEmpty()) return null
        val p = s.split(",").mapNotNull { it.trim().toIntOrNull() }
        return if (p.size == 5) p.toIntArray() else null
    }
    fun setManualTimes(c: Context, a: IntArray) = setStr(c, "manual", a.joinToString(","))
    fun clearManualTimes(c: Context) = setStr(c, "manual", "")

    // ---- user-selected blocked apps ----
    fun custom(c: Context): Set<String> = sp(c).getStringSet("custom", emptySet()) ?: emptySet()
    fun setCustom(c: Context, s: Set<String>) { sp(c).edit().putStringSet("custom", HashSet(s)).apply() }

    // ---- apps jo lock/namaz ke waqt bhi khule rahenge (WhatsApp call/msg jaise) ----
    fun allowedLock(c: Context): Set<String> = sp(c).getStringSet("allowedLock", emptySet()) ?: emptySet()
    fun setAllowedLock(c: Context, s: Set<String>) {
        sp(c).edit().putStringSet("allowedLock", HashSet(s)).apply()
        Policy.invalidate()
    }

    // ---- lock ----
    fun lockUntil(c: Context) = long(c, "lockUntil")
    fun lockReason(c: Context) = str(c, "lockReason", "locked")
    fun setLock(c: Context, until: Long, reason: String) {
        setLong(c, "lockUntil", until)
        setStr(c, "lockReason", reason)
    }
    fun clearLock(c: Context) = setLong(c, "lockUntil", 0L)

    // ---- prayers ----
    fun done(c: Context, day: String, idx: Int) = bool(c, "done_${day}_$idx")
    fun setDone(c: Context, day: String, idx: Int) = setBool(c, "done_${day}_$idx", true)
    fun missed(c: Context, day: String, idx: Int) = bool(c, "miss_${day}_$idx")
    fun setMissed(c: Context, day: String, idx: Int) = setBool(c, "miss_${day}_$idx", true)
    fun bumpMissed(c: Context, day: String): Int {
        val n = int(c, "mc_$day", 0) + 1
        setInt(c, "mc_$day", n)
        return n
    }

    // ---- daily usage ----
    private fun roll(c: Context) {
        val d = dayKey()
        if (str(c, "usedDay") != d) {
            setStr(c, "usedDay", d)
            setLong(c, "used", 0L)
        }
    }
    fun used(c: Context): Long { roll(c); return long(c, "used") }
    fun addUsed(c: Context, ms: Long) { roll(c); setLong(c, "used", long(c, "used") + ms) }
}
