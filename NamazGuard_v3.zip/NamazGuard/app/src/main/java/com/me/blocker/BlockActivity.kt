package com.me.blocker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class BlockActivity : Activity() {
    companion object {
        @Volatile var visible = false
        fun show(c: Context, reason: String) {
            if (visible) return
            val i = Intent(c, BlockActivity::class.java).putExtra("reason", reason)
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION
                )
            try { c.startActivity(i) } catch (e: Exception) {}
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var tTitle: TextView
    private lateinit var body: TextView
    private lateinit var timer: TextView
    private lateinit var btnDone: TextView
    private lateinit var btnSpeak: TextView
    private lateinit var btnEmerg: TextView
    private lateinit var btnHome: TextView
    private var cur: PrayerTimes.Prayer? = null

    private val ui = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val d = Ui.dp(this, 1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0B0B10"))
            setPadding(28 * d, 48 * d, 28 * d, 48 * d)
        }
        tTitle = Ui.text(this, "", 26f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        body = Ui.text(this, "", 16f, Color.parseColor("#C7C7CC")).apply { gravity = Gravity.CENTER }
        timer = Ui.text(this, "", 34f, Color.parseColor("#FFD60A"), true).apply { gravity = Gravity.CENTER }
        btnDone = Ui.pill(this, "📸 Namaz ka saboot (live photo)", Ui.BLUE, Color.WHITE) { onProof() }
        btnSpeak = Ui.pill(this, "🔊 Awaaz dobara", Color.parseColor("#2C2C2E"), Color.WHITE) {
            val p = cur
            if (p != null) VoiceService.speak(this, "reminder", p.idx, ((p.deadline - System.currentTimeMillis()) / 60000L).coerceAtLeast(1))
        }
        val btnPhone = Ui.pill(this, "📞 Phone / Emergency call", Ui.GREEN, Color.BLACK) {
            try { startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
        }
        btnHome = Ui.pill(this, "🏠 Home", Color.parseColor("#2C2C2E"), Color.WHITE) { goHome() }
        btnEmerg = Ui.pill(this, "🚨 Emergency unlock (30 min wait)", Color.parseColor("#3A1D1D"), Ui.RED) { onEmergency() }

        for (v in listOf<View>(tTitle, body, timer, btnDone, btnSpeak, btnPhone, btnHome, btnEmerg)) {
            root.addView(v, Ui.lp(this, 18))
        }
        val sv = ScrollView(this); sv.isFillViewport = true; sv.addView(root)
        setContentView(sv)
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); if (i != null) setIntent(i) }
    override fun onResume() {
        super.onResume(); visible = true; h.post(ui)
        Hardening.enterLockTask(this)
    }
    override fun onPause() { visible = false; h.removeCallbacks(ui); super.onPause() }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { goHome() }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        val extra = intent?.getStringExtra("reason") ?: "locked"
        val pr = if (Prefs.armed(this)) PrayerTimes.active(this, now) else null
        cur = pr
        val r: String? = when {
            pr != null -> "prayer"
            Prefs.armed(this) && Prefs.lockUntil(this) > now -> "locked"
            extra == "hard" || extra == "tamper" -> extra
            else -> null
        }
        if (r == null) { finish(); goHome(); return }

        btnDone.visibility = if (r == "prayer") View.VISIBLE else View.GONE
        btnSpeak.visibility = if (r == "prayer") View.VISIBLE else View.GONE
        val emergOk = r == "locked" && !Prefs.strict(this) && Prefs.lockReason(this) != "missed"
        btnEmerg.visibility = if (emergOk) View.VISIBLE else View.GONE
        btnHome.visibility = if (r == "hard" || r == "tamper") View.VISIBLE else View.GONE

        when (r) {
            "prayer" -> {
                val p = pr!!
                val left = ((p.deadline - now) / 60000L).coerceAtLeast(0)
                tTitle.text = "🕌 ${PrayerTimes.NAMES[p.idx]} ki namaz ka waqt"
                body.text = "Phone abhi band hai. Pehle namaz padho.\nWaqt khatam hone mein: $left min\nNamaz ke baad camera se janamaz ki LIVE photo do — sirf tick se tasdeeq nahi hogi."
                val wait = p.start + Policy.MIN_PRAYER_MS - now
                if (wait > 0) {
                    btnDone.alpha = 0.4f; btnDone.isEnabled = false
                    timer.text = "Saboot ${wait / 1000} sec baad"
                } else { btnDone.alpha = 1f; btnDone.isEnabled = true; timer.text = "" }
            }
            "locked" -> {
                val why = when (Prefs.lockReason(this)) {
                    "missed" -> "Namaz qaza hui, isliye poora phone band hai."
                    "limit" -> "Aaj ki phone limit poori ho gayi."
                    else -> "Break time: aankhon ko aaram do."
                }
                tTitle.text = "🔒 Phone band"
                body.text = why + "\nSirf call (aane wali / jaane wali) chalegi."
                timer.text = fmt(Prefs.lockUntil(this) - now)
            }
            "tamper" -> {
                tTitle.text = "🛡️ Settings band hain"
                body.text = "Strict mode ON hai. Ye sirf phone reset karne par hat-ta hai."
                timer.text = ""
            }
            else -> {
                tTitle.text = "⛔ Ye app block hai"
                body.text = "Ye app aapne khud block kiya hai (ya social media / video / game hai)."
                timer.text = ""
            }
        }
    }

    private fun onProof() {
        val p = cur ?: return
        if (System.currentTimeMillis() < p.start + Policy.MIN_PRAYER_MS) return
        startActivity(Intent(this, ProofActivity::class.java))
    }

    private fun onEmergency() {
        val now = System.currentTimeMillis()
        val today = Prefs.dayKey()
        if (Prefs.str(this, "emergDay") == today) {
            Toast.makeText(this, "Aaj ki emergency pehle use ho chuki.", Toast.LENGTH_LONG).show(); return
        }
        val req = Prefs.long(this, "emergReq")
        if (req == 0L) {
            Prefs.setLong(this, "emergReq", now)
            Toast.makeText(this, "30 min baad dobara dabao.", Toast.LENGTH_LONG).show()
        } else if (now - req >= 30 * 60000L) {
            Prefs.clearLock(this)
            Prefs.setLong(this, "emergReq", 0L)
            Prefs.setLong(this, "session", 0L)
            Prefs.setStr(this, "emergDay", today)
            Toast.makeText(this, "Emergency unlock ho gaya.", Toast.LENGTH_LONG).show()
        } else {
            val m = (30 * 60000L - (now - req)) / 60000L + 1
            Toast.makeText(this, "Abhi $m min baqi hain.", Toast.LENGTH_LONG).show()
        }
    }

    private fun goHome() {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {}
    }
}
