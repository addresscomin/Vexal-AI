package com.me.blocker

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo

class BlockerAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var currentPkg: String? = null
    }

    private var lastShadeAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (Prefs.armed(this)) {
            BlockerService.start(this)
            Scheduler.rescheduleAll(this)
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !Prefs.armed(this)) return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val pkg = e.packageName?.toString() ?: return
                if (pkg == "com.android.systemui") { closeShadeIfLocked(); return }
                currentPkg = pkg
                val r = Policy.block(this, pkg)
                if (r != null) { goHome(); BlockActivity.show(this, r) }
                sweepWindows()
            }
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> sweepWindows()
        }
    }

    /** Split-screen / floating window / pop-up: koi bhi window block-app ki ho to sab band. */
    private fun sweepWindows() {
        val ws: List<AccessibilityWindowInfo> = (try { windows } catch (e: Exception) { null }) ?: return
        var offender: String? = null
        var reason: String? = null
        var appWindows = 0
        for (w in ws) {
            if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
            appWindows++
            val pkg: String = (try { w.root?.packageName?.toString() } catch (e: Exception) { null }) ?: continue
            val r = Policy.block(this, pkg)
            if (r != null) { offender = pkg; reason = r }
        }
        val locked = Policy.ownScreenReason(this) != null
        if (offender != null || (locked && appWindows > 1)) {
            goHome()
            BlockActivity.show(this, reason ?: "locked")
        }
    }

    /** Lock/namaz ke waqt control center / notification shade band. */
    private fun closeShadeIfLocked() {
        if (Policy.ownScreenReason(this) == null) return
        val now = System.currentTimeMillis()
        if (now - lastShadeAt < 400) return
        lastShadeAt = now
        if (Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
    }

    private fun goHome() { try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (e: Exception) {} }

    override fun onInterrupt() {}
}
