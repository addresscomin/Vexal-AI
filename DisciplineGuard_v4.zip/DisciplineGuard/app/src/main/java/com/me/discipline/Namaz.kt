package com.me.discipline

/** NAMAZ MODULE ka logic (saza). Qaza: 1 = 60 min poora phone band, har agli +30 min, paanchon = 24 ghante. */
object Namaz {
    fun sweepMissed(c: android.content.Context) {
        if (!Prefs.armed(c) || !NamazPrefs.enabled(c)) return
        val now = System.currentTimeMillis()
        for (off in -1..0) {
            for (p in PrayerTimes.day(c, off).prayers) {
                if (p.start < Prefs.armedAt(c)) continue
                if (now < p.deadline) continue
                if (NamazPrefs.done(c, p.day, p.idx) || NamazPrefs.missed(c, p.day, p.idx)) continue
                NamazPrefs.setMissed(c, p.day, p.idx)
                val n = NamazPrefs.bumpMissed(c, p.day)
                val minutes = if (n >= 5) 1440 else 60 + 30 * (n - 1)
                val until = p.deadline + minutes * 60000L
                Prefs.extendLock(c, until, "missed")
                if (until > now) VoiceService.speak(c, "missed", p.idx, (until - now) / 60000L)
            }
        }
    }
}
