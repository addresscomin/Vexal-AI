package com.me.discipline

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** iOS jaisa look: grouped cards, rounded pills, SF-style colors. */
object Ui {
    val BLUE = Color.parseColor("#0A84FF")
    val RED = Color.parseColor("#FF453A")
    val GREEN = Color.parseColor("#30D158")
    val BG = Color.parseColor("#F2F2F7")
    val CARD = Color.WHITE
    val LABEL = Color.BLACK
    val SUB = Color.parseColor("#8E8E93")
    val SEP = Color.parseColor("#E5E5EA")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(color: Int, radiusPx: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radiusPx }

    fun text(c: Context, t: String, sp: Float, color: Int = LABEL, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = t; textSize = sp; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    fun pill(c: Context, t: String, bg: Int, fg: Int, onClick: () -> Unit): TextView =
        TextView(c).apply {
            text = t; textSize = 16f; setTextColor(fg); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(bg, dp(c, 14).toFloat())
            setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
            isClickable = true
            setOnClickListener { onClick() }
        }

    fun card(c: Context): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, dp(c, 14).toFloat())
            setPadding(dp(c, 16), dp(c, 8), dp(c, 16), dp(c, 8))
        }

    fun lp(c: Context, top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(c, top) }

    fun section(c: Context, parent: LinearLayout, t: String) {
        parent.addView(text(c, t.uppercase(), 12f, SUB).apply { setPadding(dp(c, 16), 0, 0, dp(c, 6)) }, lp(c, 22))
    }

    fun cardIn(c: Context, parent: LinearLayout): LinearLayout {
        val k = card(c); parent.addView(k, lp(c)); return k
    }

    fun row(c: Context, parent: LinearLayout, left: String, right: String, rightColor: Int = SUB, onClick: (() -> Unit)? = null) {
        val r = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(c, 12), 0, dp(c, 12))
        }
        r.addView(text(c, left, 16f), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(text(c, right, 16f, rightColor))
        if (onClick != null) r.setOnClickListener { onClick() }
        parent.addView(r)
        parent.addView(View(c).apply { setBackgroundColor(SEP) }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
    }

    fun field(c: Context, parent: LinearLayout, label: String, value: String, decimal: Boolean = false): EditText {
        parent.addView(text(c, label, 13f, SUB).apply { setPadding(0, dp(c, 10), 0, 0) })
        val e = EditText(c)
        e.setText(value)
        e.inputType = if (decimal) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        else InputType.TYPE_CLASS_NUMBER
        parent.addView(e)
        return e
    }
}
