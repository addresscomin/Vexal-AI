package com.me.discipline

import java.util.Calendar
import java.util.Locale

object TimeUtil {
    /** offset 0 = aaj ki raat 12 baje, 1 = kal, -1 = kal beeta */
    fun midnight(offset: Int = 0): Long {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, offset)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun minutesOfDay(ms: Long): Int {
        val cal = Calendar.getInstance(); cal.timeInMillis = ms
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    fun fmtMin(m: Int): String {
        val h = m / 60; val mm = m % 60
        val h12 = if (h % 12 == 0) 12 else h % 12
        return String.format(Locale.US, "%d:%02d %s", h12, mm, if (h < 12) "AM" else "PM")
    }
}
