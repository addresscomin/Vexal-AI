package com.me.discipline

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/** Dashboard + setup + Activate. Namaz aur Timetable ke apne alag screens hain. */
class MainActivity : Activity() {
    private lateinit var col: LinearLayout

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this) && Policy.ownScreenReason(this) != null) {
            BlockActivity.show(this, "locked")
            finish()
            return
        }
        Hardening.apply(this)
        render()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun d(v: Int) = Ui.dp(this, v)

    private fun accOn(): Boolean {
        val flat = ComponentName(this, BlockerAccessibilityService::class.java).flattenToString()
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(flat)
    }

    private fun isHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == packageName
    }

    private fun open(a: String, pkg: Boolean = true) {
        try {
            val i = Intent(a)
            if (pkg) i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (e: Exception) { toast("Ye screen nahi khuli") }
    }

    private fun perm(parent: LinearLayout, name: String, ok: Boolean, action: () -> Unit) {
        Ui.row(this, parent, name, if (ok) "✅" else "Allow karo", if (ok) Ui.GREEN else Ui.BLUE) { if (!ok) action() }
    }

    private fun render() {
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(48), d(16), d(48)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        sv.addView(col)
        setContentView(sv)

        val armed = Prefs.armed(this)
        val owner = Hardening.isOwner(this)
        val namazOn = NamazPrefs.enabled(this)

        col.addView(Ui.text(this, "Discipline Guard", 34f, Ui.LABEL, true).apply { setPadding(d(4), 0, 0, 0) })

        // ---- status ----
        val st = Ui.cardIn(this, col)
        Ui.row(this, st, "Guard", if (armed) "ACTIVE 🔒 (permanent)" else "Abhi OFF", if (armed) Ui.GREEN else Ui.RED)
        Ui.row(this, st, "Lifetime protection (Device Owner)", if (owner) "✅" else "❌", if (owner) Ui.GREEN else Ui.RED)
        Ui.row(this, st, "Aaj ka phone", "${Prefs.used(this) / 60000L} / ${Config.DAILY_LIMIT_MIN} min")
        Ui.row(this, st, "Sleep (phone band)", "${TimeUtil.fmtMin(Config.SLEEP_START_MIN)} - ${TimeUtil.fmtMin(Config.SLEEP_END_MIN)}")

        // ---- modules ----
        Ui.section(this, col, "Modules")
        val mc = Ui.cardIn(this, col)
        Ui.row(this, mc, "🕌 Namaz Guard", (if (namazOn) "ON" else "OFF") + "  ›", Ui.BLUE) {
            startActivity(Intent(this, NamazActivity::class.java))
        }
        Ui.row(this, mc, "📋 Daily Timetable", "${Timetable.all(this).size} task  ›", Ui.BLUE) {
            startActivity(Intent(this, TimetableActivity::class.java))
        }

        // ---- permissions ----
        Ui.section(this, col, "Permissions")
        val pc = Ui.cardIn(this, col)
        val pm = getSystemService(PowerManager::class.java)
        perm(pc, "Notifications", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        perm(pc, "Exact alarm", Scheduler.canExact(this)) {
            if (Build.VERSION.SDK_INT >= 31) open(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        }
        perm(pc, "Display over other apps", Settings.canDrawOverlays(this)) { open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) }
        perm(pc, "Accessibility (block engine)", accOn()) { open(Settings.ACTION_ACCESSIBILITY_SETTINGS, false) }
        perm(pc, "Device Admin (phone lock)", Policy.adminActive(this)) {
            try {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Phone lock ke liye"))
            } catch (e: Exception) { toast("Admin screen nahi khuli") }
        }
        perm(pc, "Battery optimization band", pm.isIgnoringBatteryOptimizations(packageName)) {
            open(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        }
        if (namazOn) {
            perm(pc, "Location (sahi namaz time)", checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2)
            }
        }
        perm(pc, "Discipline Home = default launcher", isHome()) { open(Settings.ACTION_HOME_SETTINGS, false) }

        if (!owner) {
            pc.addView(Ui.text(this,
                "Uninstall/disable se POORI suraksha ke liye Device Owner chahiye (Android me normal app ko ye haq nahi milta). PC se ek baar:\n\nadb shell dpm set-device-owner com.me.discipline/.AdminReceiver\n\n(Pehle phone se saare Google/other accounts hatao, phir command chalao, phir accounts wapas jodo.)",
                12f, Ui.SUB).apply { setPadding(0, d(10), 0, d(6)); setTextIsSelectable(true) })
        }

        // ---- fixed rules ----
        Ui.section(this, col, "Fixed rules (activate ke baad kabhi nahi badalte)")
        val rc = Ui.cardIn(this, col)
        rc.addView(Ui.text(this,
            "• Roz ${Config.DAILY_LIMIT_MIN / 60} ghante tak kuch block nahi. Limit poori hote hi raat 12 baje tak poora phone band (sirf call).\n" +
                "• ${TimeUtil.fmtMin(Config.SLEEP_START_MIN)} se ${TimeUtil.fmtMin(Config.SLEEP_END_MIN)} tak sleep mode: poora phone band + lock screen (sirf call; WhatsApp bhi band).\n" +
                "• Timetable ka task miss = saza (phone lock).\n" +
                "• Namaz qaza = saza (phone lock).",
            14f, Ui.LABEL).apply { setPadding(0, d(10), 0, d(10)) })

        // ---- activate ----
        Ui.section(this, col, "Guard")
        val gc = Ui.cardIn(this, col)
        if (!armed) {
            gc.addView(Ui.pill(this, "🔒 ACTIVATE (permanent)", Ui.RED, Color.WHITE) { confirmActivate() }, Ui.lp(this, 6))
            gc.addView(Ui.text(this,
                "Pehle saari permissions, Namaz waqt aur Timetable set karo, phir Activate. Activate ke baad wapas OFF ya badlav ka koi button nahi hai.",
                12f, Ui.SUB).apply { setPadding(0, d(10), 0, d(10)) })
        } else {
            gc.addView(Ui.text(this,
                "Guard permanent ACTIVE hai. Band karne ka koi button nahi hai" +
                    (if (owner) " — sirf phone factory reset se jayega." else ". (Device Owner nahi hai, isliye uninstall protection kamzor hai.)"),
                14f, Ui.SUB).apply { setPadding(0, d(10), 0, d(10)) })
        }
    }

    private fun confirmActivate() {
        if (!accOn() || !Policy.adminActive(this)) {
            toast("Pehle Accessibility aur Device Admin allow karo."); return
        }
        val et = EditText(this).apply { hint = "LOCK likho" }
        AlertDialog.Builder(this)
            .setTitle("Permanent activate")
            .setMessage("Activate ke baad:\n• Roz ${Config.DAILY_LIMIT_MIN / 60} ghante ki limit fixed\n• ${TimeUtil.fmtMin(Config.SLEEP_START_MIN)}-${TimeUtil.fmtMin(Config.SLEEP_END_MIN)} sleep lock fixed\n• Settings block, guard band nahi hoga\n• Timetable me sirf naye task jud sakte hain\n" +
                (if (Hardening.isOwner(this)) "• Uninstall sirf factory reset se\n" else "• (Device Owner nahi hai, uninstall protection kamzor)\n") +
                "\nPakka ho to neeche LOCK likho.")
            .setView(et)
            .setPositiveButton("ACTIVATE") { _, _ ->
                if (et.text.toString().trim().uppercase() == "LOCK") {
                    Prefs.activate(this)
                    Hardening.apply(this)
                    Scheduler.rescheduleAll(this)
                    BlockerService.start(this)
                    render()
                } else toast("LOCK nahi likha, cancel.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        render()
    }
}
