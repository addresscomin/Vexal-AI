package com.me.discipline

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** TIMETABLE MODULE ka alag screen: roz ka routine + saza. */
class TimetableActivity : Activity() {
    private lateinit var col: LinearLayout

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this) && Policy.ownScreenReason(this) != null) {
            BlockActivity.show(this, "locked"); finish(); return
        }
        render()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun d(v: Int) = Ui.dp(this, v)

    private fun render() {
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(48), d(16), d(48)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        sv.addView(col)
        setContentView(sv)

        col.addView(Ui.text(this, "📋 Daily Timetable", 30f, Ui.LABEL, true).apply { setPadding(d(4), 0, 0, 0) })
        col.addView(Ui.text(this,
            "Har task roz repeat hota hai. Task ke waqt me poora karke 'Done' dabao (photo wala task me live photo). Waqt nikal gaya aur done nahi = phone lock ki saza; usi din har agli miss par +15 min.",
            12f, Ui.SUB).apply { setPadding(d(4), d(8), 0, 0) })

        val tasks = Timetable.all(this)
        val now = System.currentTimeMillis()
        Ui.section(this, col, "Aaj ke task")
        val tc = Ui.cardIn(this, col)
        if (tasks.isEmpty()) {
            tc.addView(Ui.text(this, "Abhi koi task nahi. Neeche se jodo.", 14f, Ui.SUB).apply { setPadding(0, d(12), 0, d(12)) })
        }
        for (t in tasks) {
            val s = Timetable.status(this, t, now)
            val (label, color) = when (s) {
                "done" -> Pair("✅ Done", Ui.GREEN)
                "missed" -> Pair("❌ Miss", Ui.RED)
                "open" -> Pair("▶ Abhi", Ui.BLUE)
                "over" -> Pair("—", Ui.SUB)
                else -> Pair("⏳", Ui.SUB)
            }
            val sub = "${TimeUtil.fmtMin(t.start)} - ${TimeUtil.fmtMin(t.end)}" +
                (if (t.proof) "  📸" else "") + "  •  saza ${t.punishMin} min"
            Ui.row(this, tc, "${t.title}\n$sub", label, color) {
                when {
                    s == "open" -> Timetable.confirm(this, t)
                    !Prefs.armed(this) -> confirmRemove(t)
                    else -> toast("Activate ke baad task badal/hata nahi sakte.")
                }
            }
        }
        tc.addView(Ui.text(this,
            if (Prefs.armed(this)) "Abhi chal raha task tap karke Done karo. Naye task jod sakte ho; purane hata nahi sakte."
            else "Task tap karke hata sakte ho (Activate se pehle). Chal raha task tap = Done.",
            12f, Ui.SUB).apply { setPadding(0, d(8), 0, d(4)) })

        val ac = Ui.cardIn(this, col)
        ac.addView(Ui.pill(this, "➕ Naya task jodo", Ui.BLUE, Color.WHITE) { addDialog() }, Ui.lp(this, 6))
        ac.addView(Ui.text(this,
            "Task sleep time (${TimeUtil.fmtMin(Config.SLEEP_START_MIN)} - ${TimeUtil.fmtMin(Config.SLEEP_END_MIN)}) ke bahar hona chahiye.",
            12f, Ui.SUB).apply { setPadding(0, d(10), 0, d(10)) })
    }

    private fun confirmRemove(t: Timetable.Task) {
        AlertDialog.Builder(this)
            .setTitle("Task hatao?")
            .setMessage(t.title)
            .setPositiveButton("Hatao") { _, _ -> Timetable.remove(this, t.id); render() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addDialog() {
        val d1 = Ui.dp(this, 1)
        var s = 9 * 60
        var e = 10 * 60
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20 * d1, 10 * d1, 20 * d1, 0) }
        val et = EditText(this).apply { hint = "Task ka naam (jaise: Padhai, Gym)"; inputType = InputType.TYPE_CLASS_TEXT }
        val bs: TextView = Ui.pill(this, "Shuru: ${TimeUtil.fmtMin(s)}", Ui.BG, Ui.BLUE) {}
        val be: TextView = Ui.pill(this, "Khatam: ${TimeUtil.fmtMin(e)}", Ui.BG, Ui.BLUE) {}
        bs.setOnClickListener {
            TimePickerDialog(this, { _, hh, mm -> s = hh * 60 + mm; bs.text = "Shuru: ${TimeUtil.fmtMin(s)}" }, s / 60, s % 60, false).show()
        }
        be.setOnClickListener {
            TimePickerDialog(this, { _, hh, mm -> e = hh * 60 + mm; be.text = "Khatam: ${TimeUtil.fmtMin(e)}" }, e / 60, e % 60, false).show()
        }
        val cb = CheckBox(this).apply { text = "Live photo saboot zaroori"; isChecked = true }
        val pun = EditText(this).apply { hint = "Saza (min), default 30"; inputType = InputType.TYPE_CLASS_NUMBER; setText("30") }
        box.addView(et)
        box.addView(bs, Ui.lp(this, 10))
        box.addView(be, Ui.lp(this, 10))
        box.addView(cb, Ui.lp(this, 10))
        box.addView(pun)
        AlertDialog.Builder(this)
            .setTitle("Naya task")
            .setView(box)
            .setPositiveButton("Jodo") { _, _ ->
                val err = Timetable.add(this, et.text.toString(), s, e, cb.isChecked, pun.text.toString().toIntOrNull() ?: 30)
                if (err != null) toast(err)
                else {
                    Scheduler.rescheduleAll(this)
                    render()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
