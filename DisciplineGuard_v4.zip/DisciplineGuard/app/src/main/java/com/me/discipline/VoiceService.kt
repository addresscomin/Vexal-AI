package com.me.discipline

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

class VoiceService : Service(), TextToSpeech.OnInitListener {
    private class Req(val kind: String, val idx: Int, val arg: Long)

    private var tts: TextToSpeech? = null
    private var ready = false
    private var lang = "en"
    private val pending = ArrayList<Req>()
    private val outstanding = AtomicInteger(0)
    private var seq = 0
    private val h = Handler(Looper.getMainLooper())

    companion object {
        fun speak(c: Context, kind: String, idx: Int = 0, arg: Long = 0) {
            val i = Intent(c, VoiceService::class.java)
                .putExtra("kind", kind).putExtra("idx", idx).putExtra("arg", arg)
            try { c.startForegroundService(i) } catch (e: Exception) {}
        }
        fun stop(c: Context) {
            try { c.stopService(Intent(c, VoiceService::class.java)) } catch (e: Exception) {}
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val n = Notif.build(this, "voice", "Discipline Guard", "Awaaz chal rahi hai")
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(2, n)

        if (i != null) {
            pending.add(Req(i.getStringExtra("kind") ?: "adhan", i.getIntExtra("idx", 0), i.getLongExtra("arg", 0L)))
        }
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, (max * 0.9).toInt(), 0)
        } catch (e: Exception) {}

        if (tts == null) tts = TextToSpeech(this, this)
        else if (ready) flush()
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) { stopSelf(); return }
        val options = listOf(Locale("ur", "PK"), Locale("hi", "IN"), Locale.ENGLISH)
        for (loc in options) {
            val r = t.setLanguage(loc)
            if (r >= TextToSpeech.LANG_AVAILABLE) { lang = loc.language; break }
        }
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { finished() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { finished() }
        })
        ready = true
        flush()
    }

    private fun finished() {
        if (outstanding.decrementAndGet() <= 0) h.postDelayed({ stopSelf() }, 1000)
    }

    private fun flush() {
        val t = tts ?: return
        for (p in pending) {
            val txt = Messages.text(lang, p.kind, p.idx, p.arg)
            val reps = if (p.kind == "adhan") (if (p.idx == 0) 3 else 2) else 1
            repeat(reps) {
                outstanding.incrementAndGet()
                seq++
                t.speak(txt, TextToSpeech.QUEUE_ADD, null, "u$seq")
            }
        }
        pending.clear()
    }

    override fun onDestroy() {
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) {}
        super.onDestroy()
    }
}
