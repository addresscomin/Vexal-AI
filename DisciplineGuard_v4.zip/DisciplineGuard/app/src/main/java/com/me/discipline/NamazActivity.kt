package com.me.discipline

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.LocationManager
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import kotlin.math.abs

/** NAMAZ MODULE ka alag screen: ON/OFF, waqt, deadline, location, saboot record. */
class NamazActivity : Activity() {
    private lateinit var col: LinearLayout

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this) && Policy.ownScreenReason(this) != null) {
            BlockActivity.show(this, "locked"); finish(); return
        }
        render()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun d(v: Int) = Ui.dp(this, v)

    private fun render() {
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(48), d(16), d(48)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        sv.addView(col)
        setContentView(sv)

        val strict = Prefs.strict(this)
        val enabled = NamazPrefs.enabled(this)

        col.addView(Ui.text(this, "🕌 Namaz Guard", 30f, Ui.LABEL, true).apply { setPadding(d(4), 0, 0, 0) })

        val st = Ui.cardIn(this, col)
        Ui.row(this, st, "Namaz module", if (enabled) "ON ✅" else "OFF", if (enabled) Ui.GREEN else Ui.RED) {
            if (Prefs.armed(this)) toast("Activate ke baad ye badal nahi sakta.")
            else { NamazPrefs.setEnabled(this, !enabled); render() }
        }
        Ui.row(this, st, "Namaz saboot (photo)", "${NamazPrefs.proofCount(this)} jama")
        if (!enabled) {
            st.addView(Ui.text(this, "Module OFF hai: namaz ke waqt phone band nahi hoga aur qaza ki saza nahi lagegi.", 12f, Ui.SUB)
                .apply { setPadding(0, d(8), 0, d(8)) })
            return
        }

        Ui.section(this, col, "Namaz ke waqt (tap karke badlo)")
        val tc = Ui.cardIn(this, col)
        val cur = PrayerTimes.currentMinutes(this)
        for (i in 0..4) {
            Ui.row(this, tc, PrayerTimes.NAMES[i], TimeUtil.fmtMin(cur[i]), Ui.BLUE) { editTime(i, cur[i]) }
        }
        tc.addView(Ui.text(this,
            if (NamazPrefs.manualTimes(this) != null) "Aapke save kiye hue waqt chal rahe hain." else "Abhi location se calculated waqt chal rahe hain. Koi waqt badloge to saare 5 waqt save ho jayenge.",
            12f, Ui.SUB).apply { setPadding(0, d(8), 0, d(4)) })
        if (NamazPrefs.manualTimes(this) != null) {
            tc.addView(Ui.pill(this, "Calculated waqt par wapas", Ui.BG, Ui.BLUE) {
                if (PrayerTimes.active(this) != null) toast("Namaz ke waqt ye nahi badal sakte.")
                else { NamazPrefs.clearManualTimes(this); Scheduler.rescheduleAll(this); render() }
            }, Ui.lp(this, 6))
        }
        if (strict) tc.addView(Ui.text(this, "Activate ke baad: waqt calculated se sirf ±30 min tak badal sakte ho.", 12f, Ui.SUB))

        Ui.section(this, col, "Settings")
        val sc = Ui.cardIn(this, col)
        val etWin = Ui.field(this, sc, "Namaz ki deadline (waqt shuru se kitne min)", NamazPrefs.windowMin(this).toString())
        val etLat = Ui.field(this, sc, "Latitude", NamazPrefs.lat(this).toString(), true)
        val etLng = Ui.field(this, sc, "Longitude", NamazPrefs.lng(this).toString(), true)
        sc.addView(Ui.pill(this, "💾 Save", Ui.BLUE, Color.WHITE) {
            val w = (etWin.text.toString().toIntOrNull() ?: NamazPrefs.windowMin(this)).coerceIn(30, 180)
            if (Prefs.strict(this) && w > NamazPrefs.windowMin(this)) {
                toast("Activate ke baad deadline badha nahi sakte.")
            } else {
                NamazPrefs.setWindowMin(this, w)
                if (!Prefs.strict(this)) {
                    val la = etLat.text.toString().toDoubleOrNull()
                    val lo = etLng.text.toString().toDoubleOrNull()
                    if (la != null && lo != null) {
                        NamazPrefs.setStr(this, "lat", la.toString()); NamazPrefs.setStr(this, "lng", lo.toString())
                    }
                }
                Scheduler.rescheduleAll(this)
                toast("Save ho gaya")
                render()
            }
        }, Ui.lp(this, 14))
        sc.addView(Ui.pill(this, "📍 Meri location se set karo", Ui.BG, Ui.BLUE) { useLocation() }, Ui.lp(this, 10))
        sc.addView(Ui.pill(this, "🔊 Awaaz test", Ui.BG, Ui.BLUE) { VoiceService.speak(this, "adhan", 1, 0) }, Ui.lp(this, 10))
        sc.addView(View(this), Ui.lp(this, 6))

        col.addView(Ui.text(this,
            "Rules: namaz ke waqt phone band (sirf call). 5 min baad camera se LIVE photo saboot. Deadline tak saboot nahi = qaza: 1 qaza = 60 min poora phone band, har agli +30 min, paanchon = 24 ghante.",
            12f, Ui.SUB).apply { setPadding(d(4), d(14), 0, 0) })
    }

    private fun editTime(i: Int, curMin: Int) {
        if (PrayerTimes.active(this) != null) { toast("Namaz ke waqt time nahi badal sakte."); return }
        TimePickerDialog(this, { _, hh, mm ->
            val v = hh * 60 + mm
            val calc = PrayerTimes.calcMinutes(this)[i]
            if (Prefs.strict(this) && abs(v - calc) > 30) {
                toast("Activate ke baad calculated waqt (${TimeUtil.fmtMin(calc)}) se sirf ±30 min tak badal sakte ho.")
            } else {
                val arr = PrayerTimes.currentMinutes(this).copyOf()
                arr[i] = v
                NamazPrefs.setManualTimes(this, arr)
                Scheduler.rescheduleAll(this)
                toast("${PrayerTimes.NAMES[i]} ka waqt save ho gaya")
                render()
            }
        }, curMin / 60, curMin % 60, false).show()
    }

    private fun useLocation() {
        if (Prefs.strict(this)) { toast("Activate ke baad location nahi badal sakte."); return }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2); return
        }
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
                .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
                .maxByOrNull { it.time }
            if (loc == null) {
                toast("Location nahi mili. GPS on karke Maps kholo, phir dobara try karo.")
            } else {
                NamazPrefs.setStr(this, "lat", loc.latitude.toString())
                NamazPrefs.setStr(this, "lng", loc.longitude.toString())
                Scheduler.rescheduleAll(this)
                toast("Location set ho gayi")
                render()
            }
        } catch (e: Exception) { toast("Location error") }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        render()
    }
}
