package com.me.discipline

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.telecom.TelecomManager
import android.view.inputmethod.InputMethodManager
import java.util.Calendar

/**
 * Rules:
 *  - 3 ghante/din tak KUCH block nahi (sirf Settings/installer, taaki guard band na ho sake).
 *  - Namaz ka waqt / sleep (9PM-5AM) / limit poori / saza: poora phone band, SIRF CALL chalti hai.
 */
object Policy {

    /** Activate ke baad ye hamesha block: Settings (admin/accessibility band karne se rokne ke liye) + installer. */
    val TAMPER = setOf(
        "com.android.settings", "com.google.android.packageinstaller",
        "com.android.packageinstaller", "com.samsung.android.packageinstaller",
        "com.android.settings.intelligence", "com.google.android.settings.intelligence",
        "com.android.vending",
        "com.google.android.gms.setupservices"
    )

    /** Band ke waqt bhi khule: sirf phone/call + contacts + alarm ghadi (alarm band karne ke liye). */
    private val ALWAYS = setOf(
        "com.android.systemui", "android", "com.android.phone", "com.android.server.telecom",
        "com.android.incallui", "com.android.dialer", "com.google.android.dialer",
        "com.samsung.android.dialer", "com.samsung.android.incallui",
        "com.android.contacts", "com.google.android.contacts", "com.samsung.android.app.contacts",
        "com.android.emergency",
        "com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage",
        "com.oneplus.deskclock", "com.coloros.alarmclock", "com.miui.clock"
    )

    const val MIN_PRAYER_MS = 5 * 60000L

    fun invalidate() { cacheAt = 0L }

    private var camAt = 0L
    private var camCache: Set<String> = emptySet()
    fun cameraPkgs(c: Context): Set<String> {
        val now = System.currentTimeMillis()
        if (now - camAt < 60000 && camCache.isNotEmpty()) return camCache
        camCache = try {
            c.packageManager.queryIntentActivities(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 0)
                .map { it.activityInfo.packageName }.toSet()
        } catch (e: Exception) { emptySet() }
        camAt = now
        return camCache
    }

    private var cacheAt = 0L
    private var cache: Set<String> = emptySet()

    fun alwaysAllowed(c: Context): Set<String> {
        val now = System.currentTimeMillis()
        if (now - cacheAt < 60000 && cache.isNotEmpty()) return cache
        val s = HashSet<String>(ALWAYS)
        s.add(c.packageName)
        try { (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { s.add(it) } } catch (e: Exception) {}
        try {
            val imm = c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            for (m in imm.enabledInputMethodList) s.add(m.packageName)
        } catch (e: Exception) {}
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            c.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { s.add(it) }
        } catch (e: Exception) {}
        cache = s
        cacheAt = now
        return s
    }

    /** null = allow, warna reason: tamper / prayer / sleep / locked */
    fun block(c: Context, pkg: String?): String? {
        if (pkg == null || !Prefs.armed(c)) return null
        if (pkg == c.packageName) return null
        val now = System.currentTimeMillis()
        // saboot (live photo) lete waqt sirf camera app ko ijazat
        if (Prefs.long(c, "proofUntil") > now && cameraPkgs(c).contains(pkg)) return null
        if (alwaysAllowed(c).contains(pkg)) return null
        if (Prefs.strict(c) && TAMPER.contains(pkg)) return "tamper"
        return ownScreenReason(c)
    }

    /** Poora phone band hone ki wajah, ya null agar phone free hai. Namaz > sleep > lock. */
    fun ownScreenReason(c: Context): String? {
        if (!Prefs.armed(c)) return null
        val now = System.currentTimeMillis()
        if (PrayerTimes.active(c, now) != null) return "prayer"
        if (SleepMode.active(now)) return "sleep"
        if (Prefs.lockUntil(c) > now) return "locked"
        return null
    }

    fun endOfDay(): Long = TimeUtil.midnight(1)

    fun adminActive(c: Context): Boolean {
        val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(ComponentName(c, AdminReceiver::class.java))
    }
}
