package com.me.discipline

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import android.telecom.TelecomManager
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Discipline Home: iOS-style launcher.
 *  - permanently block apps (hard/custom/game/tamper) = bilkul gayab
 *  - abhi (namaz/lock/limit ki wajah se) band apps = dim, click nahi hota
 *  - allowed apps (call/SMS, WhatsApp jaise chune hue) = normal
 * Blocking ka faisla Policy.block() se hi aata hai, isliye har jagah (search, split-screen, recents) wahi rule.
 */
class HomeActivity : Activity() {
    private class Item(val pkg: String, val label: String, val icon: Drawable, val dim: Boolean)

    private val h = Handler(Looper.getMainLooper())
    private lateinit var grid: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var prayerText: TextView
    private var lastSig = ""

    private val refresher = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 3000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.TRANSPARENT
        val d = Ui.dp(this, 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#14204F"), Color.parseColor("#4B2E8F"), Color.parseColor("#C86DD7"))
            )
            setPadding(18 * d, 44 * d, 18 * d, 18 * d)
        }

        val clock = TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "H:mm"
            textSize = 64f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"
            textSize = 15f; setTextColor(Color.parseColor("#E5E5EA")); gravity = Gravity.CENTER
        }
        prayerText = Ui.text(this, "", 15f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = Ui.rounded(Color.parseColor("#33FFFFFF"), 18f * d)
            setPadding(16 * d, 12 * d, 16 * d, 12 * d)
        }
        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(grid) }
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = Ui.rounded(Color.parseColor("#40FFFFFF"), 28f * d)
            setPadding(12 * d, 12 * d, 12 * d, 12 * d)
        }

        root.addView(clock, Ui.lp(this))
        root.addView(date, Ui.lp(this))
        root.addView(prayerText, Ui.lp(this, 14))
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(dock, Ui.lp(this, 10))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this)) {
            val r = Policy.ownScreenReason(this)
            if (r != null) { BlockActivity.show(this, r); return }
        }
        Hardening.enterLockTask(this)
        lastSig = ""
        h.post(refresher)
    }

    override fun onPause() { h.removeCallbacks(refresher); super.onPause() }

    private fun appItems(): List<Item> {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<Item>()
        val seen = HashSet<String>()
        for (ri in pm.queryIntentActivities(q, 0)) {
            val pkg = ri.activityInfo.packageName
            if (!seen.add(pkg)) continue
            val why = Policy.block(this, pkg)
            if (why == "tamper") continue      // Settings/installer = invisible
            out.add(Item(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), why != null))
        }
        return out.sortedBy { it.label.lowercase() }
    }

    private fun refresh() {
        val next = PrayerTimes.next(this)
        prayerText.text = if (next != null)
            "🕌 Agli namaz: ${PrayerTimes.NAMES[next.idx]}  ${SimpleDateFormat("hh:mm a", Locale.US).format(Date(next.start))}   •   ${Prefs.used(this) / 60000L}/${Config.DAILY_LIMIT_MIN} min"
        else "📵 ${Prefs.used(this) / 60000L}/${Config.DAILY_LIMIT_MIN} min   •   Sleep ${TimeUtil.fmtMin(Config.SLEEP_START_MIN)}"

        val items = appItems()
        val sig = items.joinToString(",") { it.pkg + if (it.dim) "!" else "" }
        if (sig == lastSig) return
        lastSig = sig

        grid.removeAllViews()
        var row: LinearLayout? = null
        for ((i, a) in items.withIndex()) {
            if (i % 4 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                grid.addView(row, Ui.lp(this, 18))
            }
            row!!.addView(cell(a), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        val rem = items.size % 4
        if (rem != 0 && row != null) {
            for (k in 0 until 4 - rem) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        }

        buildDock(items)
    }

    private fun buildDock(items: List<Item>) {
        dock.removeAllViews()
        val want = ArrayList<String>()
        try { (getSystemService(TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { want.add(it) } } catch (e: Exception) {}
        try { Telephony.Sms.getDefaultSmsPackage(this)?.let { want.add(it) } } catch (e: Exception) {}
        want.addAll(Policy.cameraPkgs(this).take(1))
        want.add(packageName)
        val byPkg = items.associateBy { it.pkg }
        for (p in want.distinct()) {
            val it = byPkg[p] ?: continue
            dock.addView(cell(it, false), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
    }

    private fun cell(a: Item, showLabel: Boolean = true): View {
        val d = Ui.dp(this, 1)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val img = ImageView(this).apply {
            setImageDrawable(a.icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, v.width * 0.225f) }
            }
            clipToOutline = true
        }
        box.addView(img, LinearLayout.LayoutParams(60 * d, 60 * d))
        if (showLabel) {
            box.addView(TextView(this).apply {
                text = a.label; textSize = 11f; setTextColor(Color.WHITE); maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
                setShadowLayer(3f, 0f, 1f, Color.BLACK)
            }, Ui.lp(this, 4))
        }
        if (a.dim) {
            box.alpha = 0.32f           // abhi band: dim + click nahi
        } else {
            box.setOnClickListener {
                try {
                    val i = packageManager.getLaunchIntentForPackage(a.pkg)
                    if (i != null && Policy.block(this, a.pkg) == null) startActivity(i)
                } catch (e: Exception) {}
            }
        }
        return box
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}
}
