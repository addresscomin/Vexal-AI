package com.me.discipline

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) { Hardening.apply(context) }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Discipline Guard band karna apne aap se wada todna hai. Ye phone reset tak band nahi hota."
}
