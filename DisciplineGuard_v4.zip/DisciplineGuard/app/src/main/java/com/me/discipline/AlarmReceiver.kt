package com.me.discipline

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Prefs.armed(c)) return
        BlockerService.start(c)
        when (i.action) {
            "WATCHDOG" -> {
                Namaz.sweepMissed(c)
                Timetable.sweep(c)
                Scheduler.rescheduleAll(c)
            }
            "SLEEP" -> {
                if (SleepMode.active()) {
                    VoiceService.speak(c, "sleep", 0, 0)
                    BlockActivity.show(c, "sleep")
                }
            }
            "TASK" -> {
                val id = i.getStringExtra("id") ?: return
                if (i.getIntExtra("kind", 0) == 0) Timetable.notifyStart(c, id)
                else Timetable.sweep(c)
            }
            "PRAYER" -> {
                if (!NamazPrefs.enabled(c)) return
                val idx = i.getIntExtra("idx", 0)
                val day = i.getStringExtra("day") ?: return
                val kind = i.getIntExtra("kind", 0)
                val deadline = i.getLongExtra("deadline", 0L)
                if (kind == 7) {
                    Namaz.sweepMissed(c)
                } else if (!NamazPrefs.done(c, day, idx)) {
                    if (kind == 0) {
                        VoiceService.speak(c, "adhan", idx, 0)
                    } else {
                        val left = ((deadline - System.currentTimeMillis()) / 60000L).coerceAtLeast(1)
                        VoiceService.speak(c, "reminder", idx, left)
                    }
                    BlockActivity.show(c, "prayer")
                }
            }
        }
    }
}
