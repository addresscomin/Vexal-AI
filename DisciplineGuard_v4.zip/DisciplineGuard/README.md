# Discipline Guard v4.0 (com.me.discipline)

Pehle ka "Namaz Guard" ab ek bada discipline system hai. Namaz uska ek alag module hai.

## Build
GitHub par push karo > Actions > "Build APK" > Artifacts > `DisciplineGuard-apk`.

## Fixed rules (app me badalne ka koi raasta nahi; badalna ho to `Config.kt` me push se PEHLE)
- Roz 3 ghante (180 min) tak kuch block nahi. 3 ghante poore hote hi raat 12 baje tak poora phone band — sirf call.
- Raat 9:00 PM se subah 5:00 AM: Sleep mode. Poora phone band + lock screen. Sirf call aati/jaati hai (WhatsApp bhi band).
- Activate ke baad Guard OFF nahi hota, limit/sleep badalte nahi, Settings block, (Device Owner ho to) uninstall sirf factory reset.

## Modules (alag screen, alag storage)
1. **Namaz Guard** (`Namaz*.kt`, `PrayerTimes.kt`, store "namaz"): waqt, live-photo saboot, qaza ki saza (60 min, +30, paanchon = 24 ghante). Activate se pehle ON/OFF.
2. **Daily Timetable** (`Timetable*.kt`, store "timetable"): roz ke task (naam, start-end, photo saboot ya tap-done, saza min). Waqt nikal gaya aur done nahi = phone lock, usi din har agli miss +15 min. Task sleep time (9PM-5AM) ke bahar hona chahiye. Activate ke baad sirf naye task jud sakte hain.

## Setup (is order me)
1. App kholo, saari permissions Allow karo (Accessibility, Overlay, Device Admin, Battery, Notifications, Exact alarm, Location agar Namaz ON).
2. Namaz module me waqt/location check karo. Timetable me task jodo.
3. (Poori suraksha) PC se ek baar Device Owner banao — phone se accounts hatao, phir:
   `adb shell dpm set-device-owner com.me.discipline/.AdminReceiver`
4. Home screen par "ACTIVATE (permanent)" — LOCK likhna padta hai. Iske baad wapas nahi.

## Dhyan do
- Sirf call-related apps (dialer, contacts, incall) aur alarm ghadi band ke waqt khule rehte hain (alarm band karne ke liye).
- Timetable task ka "saboot" photo me ye nahi check hota ki kaam sach me hua; ye khud se imaandari ka system hai.
- Phone reset hone par hi ye sab khatam hota hai.
