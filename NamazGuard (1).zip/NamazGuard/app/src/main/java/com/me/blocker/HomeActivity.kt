package com.me.blocker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Simple focus launcher: sirf allowed apps dikhata hai. Optional - Settings > Home app me chuno. */
class HomeActivity : Activity() {
    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this)) {
            val r = Policy.ownScreenReason(this)
            if (r != null) { BlockActivity.show(this, r); return }
        }
        build()
    }

    private fun build() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .filter { Policy.block(this, it.activityInfo.packageName) == null }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val labels = apps.map { it.loadLabel(pm).toString() }

        val next = PrayerTimes.next(this)
        val head = TextView(this).apply {
            textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(24, 48, 24, 24)
            text = if (next != null)
                "🕌 Agli namaz: ${PrayerTimes.NAMES[next.idx]}  ${SimpleDateFormat("hh:mm a", Locale.US).format(Date(next.start))}"
            else "🕌 Namaz Guard"
        }
        val list = ListView(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        list.setOnItemClickListener { _, _, pos, _ ->
            val launch = pm.getLaunchIntentForPackage(apps[pos].activityInfo.packageName)
            if (launch != null) startActivity(launch)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B1F1A"))
        }
        root.addView(head)
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}
}
