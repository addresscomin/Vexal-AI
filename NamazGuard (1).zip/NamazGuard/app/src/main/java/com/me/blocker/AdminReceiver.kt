package com.me.blocker

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Namaz Guard band karna apne aap se wada todna hai. Pehle strict mode ki 30 min wait poori karo."
}
