package com.me.blocker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/** Installed apps ki list: tick karo = hamesha block. Strict mode me unblock nahi hota. */
class AppPickerActivity : Activity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b) }

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this) && Policy.ownScreenReason(this) != null) {
            BlockActivity.show(this, "locked"); finish(); return
        }
        build()
    }

    private fun build() {
        val pm = packageManager
        val allowed = Policy.alwaysAllowed(this)
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .distinctBy { it.first }
            .filter { it.first != packageName && !allowed.contains(it.first) }
            .sortedBy { it.second.lowercase() }

        fun fixed(pkg: String) = Policy.HARD.contains(pkg) || Policy.isGame(this, pkg)

        val labels = apps.map { if (fixed(it.first)) it.second + "  (pehle se block)" else it.second }
        val list = ListView(this)
        list.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, labels)
        val chosen = Prefs.custom(this)
        for ((i, a) in apps.withIndex()) {
            if (fixed(a.first) || chosen.contains(a.first)) list.setItemChecked(i, true)
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].first
            val on = list.isItemChecked(pos)
            if (fixed(pkg)) {
                list.setItemChecked(pos, true)
                Toast.makeText(this, "Ye app pehle se hamesha block hai.", Toast.LENGTH_SHORT).show()
                return@setOnItemClickListener
            }
            if (!on && Prefs.strict(this) && Prefs.custom(this).contains(pkg)) {
                list.setItemChecked(pos, true)
                Toast.makeText(this, "Strict mode me unblock nahi kar sakte.", Toast.LENGTH_LONG).show()
                return@setOnItemClickListener
            }
            val s = HashSet(Prefs.custom(this))
            if (on) s.add(pkg) else s.remove(pkg)
            Prefs.setCustom(this, s)
        }

        val head = TextView(this).apply {
            text = "Tick = hamesha block\n(Strict ON me unblock nahi hoga)"
            textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(24, 48, 24, 24)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B1F1A"))
        }
        root.addView(head)
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
