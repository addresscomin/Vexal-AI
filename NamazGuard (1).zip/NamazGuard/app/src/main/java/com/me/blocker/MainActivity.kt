package com.me.blocker

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var col: LinearLayout

    override fun onResume() {
        super.onResume()
        if (Prefs.armed(this) && Policy.ownScreenReason(this) != null) {
            BlockActivity.show(this, "locked")
            finish()
            return
        }
        render()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun tv(t: String, size: Float = 15f, bold: Boolean = false, color: Int = Color.BLACK) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 10, 0, 10)
        }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false
        setOnClickListener { f() }
    }

    private fun field(label: String, value: String, decimal: Boolean = false): EditText {
        col.addView(tv(label, 13f))
        val e = EditText(this)
        e.setText(value)
        e.inputType = if (decimal) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        else InputType.TYPE_CLASS_NUMBER
        col.addView(e)
        return e
    }

    private fun accOn(): Boolean {
        val flat = ComponentName(this, BlockerAccessibilityService::class.java).flattenToString()
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(flat)
    }

    private fun perm(name: String, ok: Boolean, action: () -> Unit) {
        col.addView(tv((if (ok) "✅ " else "❌ ") + name, 15f))
        if (!ok) col.addView(btn("Allow karo") { action() })
    }

    private fun open(a: String, pkg: Boolean = true) {
        try {
            val i = Intent(a)
            if (pkg) i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (e: Exception) { toast("Ye screen nahi khuli") }
    }

    private fun render() {
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 64) }
        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)

        val armed = Prefs.armed(this)
        val strict = Prefs.strict(this)
        val now = System.currentTimeMillis()

        col.addView(tv("🕌 Namaz Guard", 26f, true))
        val usedMin = Prefs.used(this) / 60000L
        col.addView(tv("Guard: ${if (armed) "ON ✅" else "OFF"}   •   Strict: ${if (strict) "ON 🔒" else "OFF"}\nAaj phone: $usedMin / ${Prefs.limitMin(this)} min"))

        col.addView(tv("Aaj ki namaz", 18f, true))
        val fmt = SimpleDateFormat("hh:mm a", Locale.US)
        for (p in PrayerTimes.day(this, 0).prayers) {
            val mark = when {
                Prefs.done(this, p.day, p.idx) -> "✅"
                Prefs.missed(this, p.day, p.idx) -> "❌"
                else -> "⏳"
            }
            col.addView(tv("$mark ${PrayerTimes.NAMES[p.idx]}   ${fmt.format(Date(p.start))}", 17f))
        }

        col.addView(tv("Permissions (sab Allow karo)", 18f, true))
        val nm = getSystemService(PowerManager::class.java)
        perm("Notifications", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        perm("Exact alarm (namaz ke time par awaaz)", Scheduler.canExact(this)) {
            if (Build.VERSION.SDK_INT >= 31) open(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        }
        perm("Display over other apps", Settings.canDrawOverlays(this)) { open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) }
        perm("Accessibility (apps block karne ke liye)", accOn()) { open(Settings.ACTION_ACCESSIBILITY_SETTINGS, false) }
        perm("Device Admin (phone lock + uninstall protection)", Policy.adminActive(this)) {
            try {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Phone lock aur uninstall protection ke liye"))
            } catch (e: Exception) { toast("Admin screen nahi khuli") }
        }
        perm("Battery optimization band", nm.isIgnoringBatteryOptimizations(packageName)) {
            open(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        }
        perm("Location (sahi namaz time ke liye)", checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2)
        }
        col.addView(btn("🏠 Namaz Home launcher chuno (optional)") { open(Settings.ACTION_HOME_SETTINGS, false) })

        col.addView(btn("📵 Apps select karo (block list)") { startActivity(Intent(this, AppPickerActivity::class.java)) })

        col.addView(tv("Settings", 18f, true))
        val etLimit = field("Roz ki phone limit (min)", Prefs.limitMin(this).toString())
        val etSession = field("Lagatar use limit (min)", Prefs.sessionMin(this).toString())
        val etBreak = field("Break (min)", Prefs.breakMin(this).toString())
        val etLat = field("Latitude", Prefs.lat(this).toString(), true)
        val etLng = field("Longitude", Prefs.lng(this).toString(), true)
        col.addView(btn("💾 Save") {
            val l = (etLimit.text.toString().toIntOrNull() ?: Prefs.limitMin(this)).coerceIn(30, 720)
            val s = (etSession.text.toString().toIntOrNull() ?: Prefs.sessionMin(this)).coerceIn(10, 240)
            val b = (etBreak.text.toString().toIntOrNull() ?: Prefs.breakMin(this)).coerceIn(1, 120)
            if (Prefs.strict(this) && (l > Prefs.limitMin(this) || s > Prefs.sessionMin(this) || b < Prefs.breakMin(this))) {
                toast("Strict mode me limit dheeli nahi kar sakte.")
            } else {
                Prefs.setInt(this, "limit", l); Prefs.setInt(this, "session", s); Prefs.setInt(this, "break", b)
                if (!Prefs.strict(this)) {
                    Prefs.setStr(this, "lat", etLat.text.toString()); Prefs.setStr(this, "lng", etLng.text.toString())
                }
                Scheduler.rescheduleAll(this)
                toast("Save ho gaya")
                render()
            }
        })
        col.addView(btn("📍 Meri location se set karo") { useLocation() })
        col.addView(btn("🔊 Awaaz test") { VoiceService.speak(this, "adhan", 1, 0) })

        col.addView(tv("Guard control", 18f, true))
        if (!armed) {
            col.addView(btn("✅ Guard ON karo") {
                Prefs.setArmed(this, true)
                Scheduler.rescheduleAll(this)
                BlockerService.start(this)
                render()
            })
        } else if (!strict) {
            col.addView(btn("🔒 Strict mode ON (settings bhi block)") { Prefs.setStrict(this, true); render() })
            col.addView(btn("Guard OFF") { Prefs.setArmed(this, false); render() })
        } else {
            val req = Prefs.long(this, "strictOffReq")
            if (req == 0L) {
                col.addView(btn("Strict OFF ki request (30 min wait)") { Prefs.setLong(this, "strictOffReq", System.currentTimeMillis()); render() })
            } else {
                val left = req + 30 * 60000L - now
                if (left > 0) {
                    col.addView(tv("Strict OFF ${left / 60000L + 1} min baad ho sakega."))
                    col.addView(btn("Request cancel") { Prefs.setLong(this, "strictOffReq", 0L); render() })
                } else {
                    col.addView(btn("Strict OFF karo") {
                        Prefs.setStrict(this, false); Prefs.setLong(this, "strictOffReq", 0L); render()
                    })
                }
            }
        }
        col.addView(tv("\nNote: Allow wali sab permissions pehle do, phir Guard ON, aakhir me Strict ON.", 12f, false, Color.GRAY))
    }

    private fun useLocation() {
        if (Prefs.strict(this)) { toast("Strict mode me location nahi badal sakte."); return }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2); return
        }
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
                .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
                .maxByOrNull { it.time }
            if (loc == null) {
                toast("Location nahi mili. GPS on karke Maps kholo, phir dobara try karo.")
            } else {
                Prefs.setStr(this, "lat", loc.latitude.toString())
                Prefs.setStr(this, "lng", loc.longitude.toString())
                Scheduler.rescheduleAll(this)
                toast("Location set ho gayi")
                render()
            }
        } catch (e: Exception) { toast("Location error") }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        render()
    }
}
