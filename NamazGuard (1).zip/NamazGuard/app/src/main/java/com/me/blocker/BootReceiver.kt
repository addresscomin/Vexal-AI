package com.me.blocker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Prefs.armed(c)) return
        Scheduler.rescheduleAll(c)
        BlockerService.start(c)
    }
}
