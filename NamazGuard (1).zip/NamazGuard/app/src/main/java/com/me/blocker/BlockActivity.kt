package com.me.blocker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class BlockActivity : Activity() {
    companion object {
        @Volatile var visible = false
        fun show(c: Context, reason: String) {
            if (visible) return
            val i = Intent(c, BlockActivity::class.java).putExtra("reason", reason)
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION
                )
            try { c.startActivity(i) } catch (e: Exception) {}
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var tTitle: TextView
    private lateinit var body: TextView
    private lateinit var timer: TextView
    private lateinit var btnDone: Button
    private lateinit var btnSpeak: Button
    private lateinit var btnEmerg: Button
    private var cur: PrayerTimes.Prayer? = null

    private val ui = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0B1F1A"))
            setPadding(48, 64, 48, 64)
        }
        tTitle = TextView(this).apply {
            textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
        }
        body = TextView(this).apply { textSize = 17f; setTextColor(Color.parseColor("#D8EDE5")); gravity = Gravity.CENTER }
        timer = TextView(this).apply {
            textSize = 30f; setTextColor(Color.parseColor("#FFD166")); gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
        }
        btnDone = mkBtn("✅ Namaz padh li") { onDone() }
        btnSpeak = mkBtn("🔊 Awaaz dobara") {
            val p = cur
            if (p != null) VoiceService.speak(this, "reminder", p.idx, ((p.deadline - System.currentTimeMillis()) / 60000L).coerceAtLeast(1))
        }
        val btnPhone = mkBtn("📞 Phone / Call") {
            try { startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
        }
        val btnHome = mkBtn("🏠 Home") { goHome() }
        btnEmerg = mkBtn("🚨 Emergency unlock (30 min wait)") { onEmergency() }

        for (v in listOf<View>(tTitle, body, timer, btnDone, btnSpeak, btnPhone, btnHome, btnEmerg)) {
            root.addView(v, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 28 })
        }
        val sv = ScrollView(this); sv.isFillViewport = true; sv.addView(root)
        setContentView(sv)
    }

    private fun mkBtn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 16f
        setOnClickListener { f() }
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); if (i != null) setIntent(i) }
    override fun onResume() { super.onResume(); visible = true; h.post(ui) }
    override fun onPause() { visible = false; h.removeCallbacks(ui); super.onPause() }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { goHome() }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        val extra = intent?.getStringExtra("reason") ?: "locked"
        val pr = if (Prefs.armed(this)) PrayerTimes.active(this, now) else null
        cur = pr
        val r: String? = when {
            pr != null -> "prayer"
            Prefs.armed(this) && Prefs.lockUntil(this) > now -> "locked"
            extra == "hard" || extra == "tamper" -> extra
            else -> null
        }
        if (r == null) { finish(); goHome(); return }

        btnDone.visibility = if (r == "prayer") View.VISIBLE else View.GONE
        btnSpeak.visibility = if (r == "prayer") View.VISIBLE else View.GONE
        btnEmerg.visibility = if (r == "locked") View.VISIBLE else View.GONE

        when (r) {
            "prayer" -> {
                val p = pr!!
                val left = ((p.deadline - now) / 60000L).coerceAtLeast(0)
                tTitle.text = "🕌 ${PrayerTimes.NAMES[p.idx]} ki namaz ka waqt"
                body.text = "Phone abhi band hai. Pehle namaz padho.\nWaqt khatam hone mein: $left min\nNamaz ke baad neeche tasdeeq dabao."
                val wait = p.start + 3 * 60000L - now
                if (wait > 0) { btnDone.isEnabled = false; timer.text = "Tasdeeq ${wait / 1000} sec baad" }
                else { btnDone.isEnabled = true; timer.text = "" }
            }
            "locked" -> {
                val why = when (Prefs.lockReason(this)) {
                    "missed" -> "Namaz qaza hui, isliye phone band hai."
                    "limit" -> "Aaj ki phone limit poori ho gayi."
                    else -> "Break time: aankhon ko aaram do."
                }
                tTitle.text = "🔒 Phone band"
                body.text = why + "\nSirf call/SMS chalenge."
                timer.text = fmt(Prefs.lockUntil(this) - now)
            }
            "tamper" -> {
                tTitle.text = "🛡️ Settings band hain"
                body.text = "Strict mode ON hai. Band karne ke liye Namaz Guard app me 30 min wait wali request do."
                timer.text = ""
            }
            else -> {
                tTitle.text = "⛔ Ye app block hai"
                body.text = "Ye app hamesha ke liye band hai (social media / video / games)."
                timer.text = ""
            }
        }
    }

    private fun onDone() {
        val p = cur ?: return
        if (System.currentTimeMillis() < p.start + 3 * 60000L) return
        Prefs.setDone(this, p.day, p.idx)
        VoiceService.stop(this)
        VoiceService.speak(this, "done", p.idx, 0)
        finish()
        goHome()
    }

    private fun onEmergency() {
        val now = System.currentTimeMillis()
        val today = Prefs.dayKey()
        if (Prefs.str(this, "emergDay") == today) {
            Toast.makeText(this, "Aaj ki emergency pehle use ho chuki.", Toast.LENGTH_LONG).show(); return
        }
        val req = Prefs.long(this, "emergReq")
        if (req == 0L) {
            Prefs.setLong(this, "emergReq", now)
            Toast.makeText(this, "30 min baad dobara dabao.", Toast.LENGTH_LONG).show()
        } else if (now - req >= 30 * 60000L) {
            Prefs.clearLock(this)
            Prefs.setLong(this, "emergReq", 0L)
            Prefs.setLong(this, "session", 0L)
            Prefs.setStr(this, "emergDay", today)
            Toast.makeText(this, "Emergency unlock ho gaya.", Toast.LENGTH_LONG).show()
        } else {
            val m = (30 * 60000L - (now - req)) / 60000L + 1
            Toast.makeText(this, "Abhi $m min baqi hain.", Toast.LENGTH_LONG).show()
        }
    }

    private fun goHome() {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {}
    }
}
