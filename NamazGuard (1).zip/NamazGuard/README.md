# Namaz Guard (com.me.blocker)

Personal phone-discipline app: namaz ke waqt awaaz, namaz tak phone band, namaz qaza = phone lock,
roz ki limit, hamesha-block apps, strict mode.

## APK banane ka tareeqa (GitHub)
1. Is folder ko GitHub repo me push karo (ya Upload files).
2. Repo > **Actions** > "Build APK" > latest run > **Artifacts** > `NamazGuard-apk`.
3. Purani app (same package) pehle uninstall karo (device admin pehle deactivate karna hoga).

## Pehli baar setup
1. App kholo, har permission "Allow karo".
2. "Guard ON karo".
3. Sab theek chale to "Strict mode ON".

## Rules
- Namaz ka waqt: baqi sab apps band, sirf call/SMS. 3 min baad "Namaz padh li" button khulta hai.
- Namaz ki deadline (waqt ke 90 min ya window end) tak confirm nahi hui = qaza: phone lock
  (Fajr 3 ghante, baaki 1 ghanta, har agli qaza par +30 min).
- Roz ki limit (default 150 min) ke baad din bhar lock. Lagatar 45 min use par 10 min break.
- Social media / video / games hamesha block (Policy.kt > HARD). App me "Apps select karo" se apne apps bhi tick karke block karo.
- Strict mode: Settings app bhi block; band karne ke liye 30 min wait.
- Emergency unlock: roz 1 baar, 30 min wait ke baad (sirf lock ke liye, namaz ke waqt nahi).
- Data wipe / factory reset isme JAAN BOOJH KAR nahi hai.
